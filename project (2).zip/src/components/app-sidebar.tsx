
"use client"

import * as React from "react"
import {
  LayoutDashboard,
  Ship,
  Users,
  FileText,
  Calculator,
  Bell,
  Settings,
  LogOut,
  Plane,
  ReceiptText,
  QrCode,
  Search,
  PieChart,
} from "lucide-react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { signOut } from "firebase/auth"
import { useAuth, useUser, useFirestore, useCollection, useMemoFirebase } from "@/firebase"
import { useSidebar } from "@/components/ui/sidebar"
import { query, collection, where, limit } from "firebase/firestore"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent,
} from "@/components/ui/sidebar"
import { SheetTitle, SheetDescription } from "@/components/ui/sheet"
import { Badge } from "@/components/ui/badge"

export function AppSidebar() {
  const pathname = usePathname()
  const auth = useAuth()
  const db = useFirestore()
  const router = useRouter()
  const { user } = useUser()
  const { isMobile } = useSidebar()

  const [effectiveEmail, setEffectiveEmail] = React.useState<string | null>(null)
  
  React.useEffect(() => {
    setEffectiveEmail(user?.email || (typeof window !== 'undefined' ? sessionStorage.getItem("ghaLink_guest_email") : null))
  }, [user])

  const clientsRef = useMemoFirebase(() => db ? collection(db, 'clients') : null, [db])
  const clientMatchQuery = useMemoFirebase(() => {
    if (!clientsRef || !effectiveEmail) return null
    return query(clientsRef, where('email', '==', effectiveEmail), limit(1))
  }, [clientsRef, effectiveEmail])
  
  const { data: clientRecord } = useCollection(clientMatchQuery)

  const clientData = React.useMemo(() => {
    if (clientRecord && clientRecord.length > 0) return clientRecord[0]
    if (effectiveEmail === "demo@client.com") return { name: "Demo Client", id: "demo-uid" }
    return null
  }, [clientRecord, effectiveEmail])

  const isClient = !!clientData

  const handleSignOut = () => {
    sessionStorage.removeItem("ghaLink_guest")
    sessionStorage.removeItem("ghaLink_guest_email")
    signOut(auth).then(() => router.push("/login")).catch(() => router.push("/login"))
  }

  const adminNavigation = [
    { name: "Dashboard", href: "/", icon: LayoutDashboard },
    { name: "Shipments", href: "/shipments", icon: Ship },
    { name: "Scan QR", href: "/scan", icon: QrCode },
    { name: "Invoices", href: "/invoices", icon: ReceiptText },
    { name: "Financial Reports", href: "/reports", icon: PieChart },
    { name: "Clients", href: "/clients", icon: Users },
    { name: "Documents", href: "/documents", icon: FileText },
    { name: "Cost Calculator", href: "/calculator", icon: Calculator },
    { name: "Notifications", href: "/notifications", icon: Bell },
  ]

  const clientNavigation = [
    { name: "My Dashboard", href: "/", icon: LayoutDashboard },
    { name: "My Shipments", href: "/shipments", icon: Ship },
    { name: "Quick Track", href: "/track", icon: Search },
    { name: "My Invoices", href: "/invoices", icon: ReceiptText },
    { name: "Spending Statement", href: "/reports", icon: PieChart },
    { name: "Cost Calculator", href: "/calculator", icon: Calculator },
    { name: "Notifications", href: "/notifications", icon: Bell },
  ]

  const navigation = isClient ? clientNavigation : adminNavigation

  return (
    <Sidebar variant="inset">
      {isMobile && (
        <div className="sr-only">
          <SheetTitle>SNOC LOGISTICS AND CARGO Navigation</SheetTitle>
          <SheetDescription>Primary administrative controls for shipping operations.</SheetDescription>
        </div>
      )}

      <SidebarHeader className="p-4 border-b border-sidebar-border bg-sidebar">
        <div className="flex items-center gap-3">
          <div className="bg-white rounded-lg p-2 text-primary shadow-lg flex items-center justify-center border-b-2 border-accent">
            <Plane size={20} className="stroke-[3px]" />
          </div>
          <div>
            <h1 className="font-headline font-black text-xl leading-none italic tracking-tighter text-white">SNOC</h1>
            <p className="text-xs text-accent uppercase tracking-[0.1em] font-black text-[7px] mt-0.5 whitespace-nowrap">LOGISTICS AND CARGO</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent className="bg-sidebar">
        <SidebarGroup>
          <SidebarGroupLabel className="text-sidebar-foreground/40 font-bold uppercase tracking-widest text-[10px]">
            {isClient ? "Client Portal" : "Operations Hub"}
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navigation.map((item) => (
                <SidebarMenuItem key={item.name}>
                  <SidebarMenuButton 
                    asChild 
                    isActive={pathname === item.href}
                    tooltip={item.name}
                    className="hover:bg-accent/10 data-[active=true]:bg-accent data-[active=true]:text-white transition-all duration-200"
                  >
                    <Link href={item.href}>
                      <item.icon className={pathname === item.href ? "text-white" : "text-sidebar-foreground/70"} />
                      <span>{item.name}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {!isClient && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-sidebar-foreground/40 font-bold uppercase tracking-widest text-[10px]">Administration</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={pathname === "/settings"} className="hover:bg-accent/10 data-[active=true]:bg-accent data-[active=true]:text-white">
                    <Link href="/settings">
                      <Settings className={pathname === "/settings" ? "text-white" : "text-sidebar-foreground/70"} />
                      <span>Global Settings</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter className="p-4 border-t border-sidebar-border bg-sidebar">
        <SidebarMenu>
          <SidebarMenuItem className="mb-2">
            <div className="flex flex-col gap-2 p-2 rounded-lg bg-white/5 border border-white/10">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-full bg-accent flex items-center justify-center text-white font-black text-[10px] uppercase">
                  {isClient && effectiveEmail === "demo@client.com" ? "DC" : (user?.displayName?.substring(0, 2) || "SN")}
                </div>
                <div className="flex-1 overflow-hidden text-white">
                  <p className="text-[11px] font-bold truncate uppercase">{effectiveEmail === "demo@client.com" ? "Demo Client" : (user?.displayName || "Staff")}</p>
                  <p className="text-[9px] text-sidebar-foreground/50 truncate italic">{isClient ? "Private Account" : "Access Level: Staff"}</p>
                </div>
              </div>
              {isClient && clientData && (
                 <Badge variant="outline" className="w-full justify-center bg-white/10 border-white/20 text-white font-black italic text-[9px] uppercase tracking-widest py-1">
                   ID: SN-{clientData.id.substring(0, 4).toUpperCase()}
                 </Badge>
              )}
            </div>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton onClick={handleSignOut} className="text-red-400 hover:text-white hover:bg-red-500/20 font-bold text-xs uppercase tracking-wide">
              <LogOut size={14} />
              <span>Log out</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  )
}
