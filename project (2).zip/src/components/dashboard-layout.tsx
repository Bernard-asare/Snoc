"use client"

import { SidebarProvider, SidebarInset, SidebarTrigger } from "@/components/ui/sidebar"
import { AppSidebar } from "@/components/app-sidebar"
import { Separator } from "@/components/ui/separator"
import { Bell, Search, User, LogOut, Loader2, Settings as LucideSettings } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { useUser, useAuth } from "@/firebase"
import { useRouter, usePathname } from "next/navigation"
import { useEffect, useState } from "react"
import { signOut } from "firebase/auth"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import Link from "next/link"

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { user, loading } = useUser()
  const auth = useAuth()
  const router = useRouter()
  const pathname = usePathname()
  const [isGuest, setIsGuest] = useState<boolean>(false)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const guestFlag = typeof window !== 'undefined' && sessionStorage.getItem("ghaLink_guest") === "true"
    setIsGuest(guestFlag)

    if (!loading && !user && !guestFlag && pathname !== "/track" && pathname !== "/login") {
      router.push("/login")
    }
  }, [user, loading, router, pathname])

  const handleSignOut = () => {
    sessionStorage.removeItem("ghaLink_guest")
    signOut(auth).then(() => router.push("/login")).catch(() => router.push("/login"))
  }

  if (!mounted || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  const hasAccess = user || isGuest || pathname === "/track" || pathname === "/login"

  if (!hasAccess && pathname !== "/login" && pathname !== "/track") {
    return null
  }

  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset className="bg-background">
        <header className="flex h-16 shrink-0 items-center justify-between gap-2 px-4 sticky top-0 bg-background/80 backdrop-blur-sm z-10 border-b">
          <div className="flex items-center gap-2">
            <SidebarTrigger />
            <Separator orientation="vertical" className="mr-2 h-4" />
            <div className="relative w-64 hidden md:block">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search tracking #..."
                className="pl-8 bg-muted/50 border-none focus-visible:ring-1"
              />
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="icon" className="relative group">
                  <Bell className="h-5 w-5" />
                  <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-accent animate-pulse"></span>
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80 p-0" align="end">
                <div className="p-4 border-b font-semibold bg-primary/5 text-primary italic uppercase tracking-tight">SNOC OPERATIONAL ALERTS</div>
                <div className="max-h-[300px] overflow-auto">
                  <div className="p-4 border-b hover:bg-muted/50 cursor-pointer transition-colors" onClick={() => router.push('/notifications?id=1')}>
                    <p className="text-sm font-bold text-primary">Shipment GL-1005 Arrived</p>
                    <p className="text-[11px] text-muted-foreground mt-1">Cargo is at Tema Port Terminal 3 awaiting clearance.</p>
                  </div>
                </div>
              </PopoverContent>
            </Popover>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <User className="h-5 w-5 text-primary" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel className="flex flex-col">
                  <span className="text-sm font-black italic text-primary uppercase">{user?.displayName || (isGuest ? "Guest Admin" : "Staff")}</span>
                  <span className="text-[10px] text-muted-foreground font-bold">{user?.email || "Authorized Access"}</span>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/settings" className="flex items-center">
                    <LucideSettings className="mr-2 h-4 w-4" /> System Settings
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleSignOut} className="text-destructive font-bold">
                  <LogOut className="mr-2 h-4 w-4" /> Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>
        <main className="p-4 md:p-8 max-w-7xl mx-auto w-full">
          {children}
        </main>
      </SidebarInset>
    </SidebarProvider>
  )
}
