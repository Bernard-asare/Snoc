'use client';

import { useEffect } from 'react';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';
import { useToast } from '@/hooks/use-toast';

export function FirebaseErrorListener() {
  const { toast } = useToast();

  useEffect(() => {
    const handleError = (error: FirestorePermissionError) => {
      // In development, we allow the uncaught error to trigger the Next.js overlay
      // for better debugging of Security Rules.
      if (process.env.NODE_ENV === 'development') {
        throw error;
      }

      toast({
        variant: 'destructive',
        title: 'Permission Denied',
        description: `You don't have permission to perform this action.`,
      });
    };

    errorEmitter.on('permission-error', handleError);
    return () => {
      errorEmitter.off('permission-error', handleError);
    };
  }, [toast]);

  return null;
}
