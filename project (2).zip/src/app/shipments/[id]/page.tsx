
"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useDoc, useFirestore, useMemoFirebase, useUser, useCollection } from "@/firebase"
import { doc, updateDoc, serverTimestamp, arrayUnion, query, collection, where, limit } from "firebase/firestore"
import { useParams, useRouter } from "next/navigation"
import { 
  ArrowLeft, 
  Package, 
  Truck, 
  MapPin, 
  Calendar, 
  DollarSign, 
  Scale, 
  Layers, 
  Ship, 
  Plane, 
  CheckCircle2, 
  Clock,
  Loader2,
  FileText,
  Hash,
  Wand2,
  Download,
  Printer,
  QrCode,
  History,
  ShoppingCart,
  Ruler
} from "lucide-react"
import { useState, useEffect, useMemo } from "react"
import { useToast } from "@/hooks/use-toast"
import { errorEmitter } from "@/firebase/error-emitter"
import { FirestorePermissionError } from "@/firebase/errors"
import { generateShippingDocuments, GenerateShippingDocumentsOutput } from "@/ai/flows/generate-shipping-documents"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog"
import { QRCodeSVG } from "qrcode.react"
import { format } from "date-fns"

export default function ShipmentDetailPage() {
  const { id } = useParams()
  const db = useFirestore()
  const router = useRouter()
  const { user } = useUser()
  const { toast } = useToast()
  
  const [updating, setUpdating] = useState(false)
  const [generatingDocs, setGeneratingDocs] = useState(false)
  const [isAiModalOpen, setIsAiModalOpen] = useState(false)
  
  // Identify Role
  const [effectiveEmail, setEffectiveEmail] = useState<string | null>(null)
  useEffect(() => {
    setEffectiveEmail(user?.email || (typeof window !== 'undefined' ? sessionStorage.getItem("ghaLink_guest_email") : null))
  }, [user])

  const clientsRef = useMemoFirebase(() => db ? collection(db, 'clients') : null, [db])
  const clientMatchQuery = useMemoFirebase(() => {
    if (!clientsRef || !effectiveEmail) return null
    return query(clientsRef, where('email', '==', effectiveEmail), limit(1))
  }, [clientsRef, effectiveEmail])
  
  const { data: clientRecord } = useCollection(clientMatchQuery)
  const isClient = !!(clientRecord && clientRecord.length > 0) || effectiveEmail === "demo@client.com"

  const shipmentRef = useMemoFirebase(() => db && id ? doc(db, 'shipments', id as string) : null, [db, id])
  const { data: shipment, loading } = useDoc(shipmentRef)

  const handleStatusUpdate = (newStatus: string) => {
    if (!db || !shipment) return
    setUpdating(true)

    const milestone = {
      status: newStatus,
      timestamp: new Date().toISOString(),
      location: newStatus === "Warehouse" ? "China Hub" : newStatus === "Customs" ? "Ghana Port" : "Transit Hub",
      note: `Status updated to ${newStatus} by staff.`
    }

    const updateData = { 
      status: newStatus, 
      updatedAt: serverTimestamp(),
      milestones: arrayUnion(milestone)
    }

    updateDoc(doc(db, 'shipments', shipment.id), updateData)
      .then(() => {
        toast({ title: "Status Updated", description: `Shipment is now marked as ${newStatus}.` })
      })
      .catch(async (err) => {
        const permissionError = new FirestorePermissionError({
          path: `shipments/${shipment.id}`,
          operation: 'update',
          requestResourceData: updateData,
        })
        errorEmitter.emit('permission-error', permissionError)
      })
      .finally(() => setUpdating(false))
  }

  const handleGenerateAiDocs = async () => {
    if (!shipment || !db) return
    setGeneratingDocs(true)
    
    try {
      const input = {
        shipmentId: shipment.trackingId,
        senderName: "Shenzhen Logistics Hub",
        senderAddress: shipment.origin || "Shenzhen, China",
        recipientName: shipment.clientName || "Valued Client",
        recipientAddress: shipment.destination || "Ghana Hub",
        items: shipment.items || [{ description: "General Cargo", quantity: 1, valuePerItem: shipment.declaredValue, hsCode: "0000.00" }],
        totalWeightKg: shipment.weight || 0,
        totalVolumeCbm: shipment.volume || 0,
        declaredValue: shipment.declaredValue || 0,
        currency: "USD",
        countryOfOrigin: "China",
        purposeOfShipment: "Sale",
        shippingDate: shipment.date || new Date().toISOString().split('T')[0],
      }
      
      const output = await generateShippingDocuments(input)
      
      const aiDocsData = {
        aiDocuments: {
          ...output,
          generatedAt: new Date().toISOString()
        }
      }
      
      updateDoc(doc(db, 'shipments', shipment.id), aiDocsData)
      setIsAiModalOpen(true)
      toast({ title: "AI Generation Success" })
    } catch (error) {
      toast({ variant: "destructive", title: "AI Error" })
    } finally {
      setGeneratingDocs(false)
    }
  }

  if (loading) return <DashboardLayout><div className="flex justify-center p-20"><Loader2 className="animate-spin h-8 w-8 text-primary" /></div></DashboardLayout>
  if (!shipment) return <DashboardLayout><div className="text-center py-20 font-black italic text-muted-foreground">Shipment Not Found</div></DashboardLayout>

  const existingAiDocs = shipment.aiDocuments

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <Button variant="ghost" onClick={() => router.back()} className="font-bold text-[10px] uppercase tracking-widest">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back
          </Button>
          <div className="flex gap-2">
            {!isClient && (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={existingAiDocs ? () => setIsAiModalOpen(true) : handleGenerateAiDocs} 
                disabled={generatingDocs} 
                className="font-bold text-[10px] uppercase text-primary italic border-primary/20"
              >
                {generatingDocs ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Wand2 className="mr-2 h-4 w-4" />}
                {existingAiDocs ? "View AI Docs" : "AI Generate Docs"}
              </Button>
            )}
            {!isClient && (
              <Button variant="default" size="sm" asChild className="bg-accent font-bold text-[10px] uppercase">
                <a href={`/invoices/new?shipmentId=${shipment.id}`}>
                  <FileText className="mr-2 h-4 w-4" /> Create Invoice
                </a>
              </Button>
            )}
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-none shadow-sm overflow-hidden">
              <CardHeader className="bg-primary text-white border-b-4 border-accent">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-3xl font-black italic tracking-tighter uppercase">{shipment.trackingId}</CardTitle>
                    <CardDescription className="text-white/70 uppercase text-[10px] font-bold tracking-widest">{shipment.status} • {shipment.method} Freight</CardDescription>
                  </div>
                  <div className="bg-white/10 p-3 rounded-full">
                    {shipment.method === 'Air' ? <Plane size={32} /> : <Ship size={32} />}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-8">
                {/* Visual Highlights for Purchased Items and CBM */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                   <div className="bg-accent/5 border-2 border-accent/10 rounded-xl p-4 flex flex-col items-center justify-center text-center">
                      <Ruler className="text-accent mb-2" size={24} />
                      <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Cargo Volume</p>
                      <p className="text-3xl font-black italic text-primary">{shipment.volume || 0} CBM</p>
                   </div>
                   <div className="bg-primary/5 border-2 border-primary/10 rounded-xl p-4 flex flex-col items-center justify-center text-center">
                      <Scale className="text-primary mb-2" size={24} />
                      <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Total Weight</p>
                      <p className="text-3xl font-black italic text-primary">{shipment.weight || 0} kg</p>
                   </div>
                   <div className="bg-muted border-2 border-black/5 rounded-xl p-4 flex flex-col items-center justify-center text-center">
                      <ShoppingCart className="text-muted-foreground mb-2" size={24} />
                      <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Purchase Items</p>
                      <p className="text-3xl font-black italic text-primary">{shipment.items?.length || 0}</p>
                   </div>
                </div>

                <div className="border-t pt-8">
                  <h4 className="text-lg font-black italic uppercase text-primary tracking-tighter mb-4 flex items-center gap-2">
                    <ShoppingCart size={20} className="text-accent" />
                    List of Purchased Items
                  </h4>
                  <div className="grid gap-3">
                    {shipment.items?.map((item: any, i: number) => (
                      <div key={i} className="flex flex-col md:flex-row md:items-center justify-between p-4 rounded-lg bg-white border-2 border-muted hover:border-primary/20 transition-colors shadow-sm">
                        <div className="flex gap-4 items-center">
                           <div className="h-10 w-10 bg-muted rounded-full flex items-center justify-center font-black italic text-primary">
                             #{i + 1}
                           </div>
                           <div>
                              <p className="font-black text-primary uppercase text-sm">{item.description}</p>
                              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">HS CODE: {item.hsCode || 'N/A'}</p>
                           </div>
                        </div>
                        <div className="mt-4 md:mt-0 flex gap-6 text-right">
                           <div>
                              <p className="text-[9px] font-bold text-muted-foreground uppercase">Quantity</p>
                              <p className="font-black italic text-primary">{item.quantity} units</p>
                           </div>
                           <div>
                              <p className="text-[9px] font-bold text-muted-foreground uppercase">Unit Value</p>
                              <p className="font-black italic text-accent">${item.valuePerItem?.toLocaleString()}</p>
                           </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-8 border-t pt-8 grid grid-cols-2 gap-6">
                  <div>
                    <Label className="text-[10px] uppercase font-bold text-muted-foreground">Origin Port</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <MapPin size={14} className="text-accent" />
                      <p className="font-bold text-sm uppercase">{shipment.origin}</p>
                    </div>
                  </div>
                  <div>
                    <Label className="text-[10px] uppercase font-bold text-muted-foreground">Destination Terminal</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <MapPin size={14} className="text-primary" />
                      <p className="font-bold text-sm uppercase">{shipment.destination}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-black italic text-primary uppercase tracking-tighter flex items-center gap-2">
                  <History className="h-5 w-5" />
                  Journey Milestones
                </CardTitle>
                <CardDescription className="text-[10px] uppercase font-bold tracking-widest">History of all logistical status updates.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="relative space-y-6 before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-primary/20 before:to-transparent">
                  {shipment.milestones && shipment.milestones.length > 0 ? (
                    [...shipment.milestones].reverse().map((m: any, i: number) => (
                      <div key={i} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                        <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-primary text-white shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
                          <CheckCircle2 size={16} />
                        </div>
                        <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded-xl border bg-white shadow-sm transition-all hover:shadow-md">
                          <div className="flex items-center justify-between mb-1">
                            <div className="font-black italic text-primary uppercase text-xs">{m.status}</div>
                            <time className="font-bold text-[9px] text-muted-foreground uppercase">{m.timestamp ? format(new Date(m.timestamp), 'MMM d, HH:mm') : 'N/A'}</time>
                          </div>
                          <div className="text-[10px] text-muted-foreground font-medium italic">
                            {m.location && <span className="text-accent font-bold not-italic mr-1">[{m.location}]</span>}
                            {m.note}
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8">
                       <Clock size={40} className="mx-auto text-muted-foreground/20 mb-3" />
                       <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">No milestones recorded yet.</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            {!isClient && (
              <Card className="border-none shadow-md bg-accent/5">
                <CardHeader>
                  <CardTitle className="text-lg font-black italic text-primary uppercase tracking-tighter">Status Control</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Select defaultValue={shipment.status} onValueChange={handleStatusUpdate} disabled={updating}>
                    <SelectTrigger className="h-12 border-primary/20 bg-white font-black italic uppercase">
                      <SelectValue placeholder="Update status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Warehouse">Warehouse (China)</SelectItem>
                      <SelectItem value="In Transit">In Transit</SelectItem>
                      <SelectItem value="Customs">Customs (Ghana)</SelectItem>
                      <SelectItem value="Delivered">Delivered</SelectItem>
                    </SelectContent>
                  </Select>
                  {updating && <p className="text-[9px] font-black uppercase text-primary animate-pulse text-center">Synching with hub...</p>}
                </CardContent>
              </Card>
            )}

            <Card className="border-none bg-primary text-white shadow-lg relative overflow-hidden">
               <div className="absolute top-0 right-0 p-4 opacity-10">
                  <QrCode size={80} />
               </div>
               <CardHeader>
                 <CardTitle className="text-xs uppercase tracking-widest font-black opacity-80">Shipment ID</CardTitle>
               </CardHeader>
               <CardContent className="space-y-4 relative z-10">
                  <div className="p-3 bg-white/10 rounded-lg border border-white/20">
                     <p className="text-center text-3xl font-black italic tracking-widest">{shipment.trackingId}</p>
                  </div>
                  <div className="space-y-3">
                     <div className="flex justify-between items-center text-[10px]">
                        <span className="opacity-70 uppercase font-bold">Consignee</span>
                        <span className="font-black italic uppercase">{shipment.clientName}</span>
                     </div>
                     <div className="flex justify-between items-center text-[10px]">
                        <span className="opacity-70 uppercase font-bold">Registration</span>
                        <span className="font-black italic uppercase">{shipment.date}</span>
                     </div>
                  </div>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" className="w-full border-white/20 text-white hover:bg-white/10 font-black uppercase italic tracking-wider text-[10px]">
                        View Terminal QR Label
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md text-center">
                      <DialogHeader>
                        <DialogTitle className="text-primary italic uppercase tracking-tighter text-center">Package Label</DialogTitle>
                      </DialogHeader>
                      <div className="flex flex-col items-center justify-center p-8 space-y-6">
                        <div className="p-4 bg-white rounded-xl shadow-xl border-4 border-primary">
                           <QRCodeSVG value={shipment.trackingId} size={200} level="H" includeMargin={true} />
                        </div>
                        <p className="text-2xl font-black italic text-primary uppercase">{shipment.trackingId}</p>
                      </div>
                    </DialogContent>
                  </Dialog>
               </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <Dialog open={isAiModalOpen} onOpenChange={setIsAiModalOpen}>
        <DialogContent className="max-w-4xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-primary font-black italic uppercase tracking-tighter text-2xl">AI Shipping Documentation</DialogTitle>
          </DialogHeader>
          {existingAiDocs && (
            <div className="space-y-6 pt-4">
              <div className="p-4 rounded-lg bg-accent/5 border border-accent/20">
                <p className="text-sm italic">{existingAiDocs.summary}</p>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-[10px] font-bold uppercase">Customs Declaration</Label>
                  <pre className="p-4 bg-muted rounded text-[10px] font-mono whitespace-pre-wrap max-h-[350px] overflow-auto">{existingAiDocs.customsDeclaration}</pre>
                </div>
                <div className="space-y-2">
                  <Label className="text-[10px] font-bold uppercase">Packing List</Label>
                  <pre className="p-4 bg-muted rounded text-[10px] font-mono whitespace-pre-wrap max-h-[350px] overflow-auto">{existingAiDocs.packingList}</pre>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  )
}
