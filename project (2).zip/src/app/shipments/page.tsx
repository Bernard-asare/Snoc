
"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Search, Filter, Ship, MoreVertical, Plus, Loader2, Trash2, Eye, LayoutGrid, CheckCircle2, Megaphone, Clock } from "lucide-react"
import Link from "next/link"
import { useState, useEffect, useMemo } from "react"
import { useCollection, useFirestore, useMemoFirebase, useUser } from "@/firebase"
import { collection, deleteDoc, doc, query, where, updateDoc, serverTimestamp, arrayUnion, limit } from "firebase/firestore"
import { useToast } from "@/hooks/use-toast"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"

export default function ShipmentsPage() {
  const db = useFirestore()
  const { user } = useUser()
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedShipments, setSelectedShipments] = useState<string[]>([])
  const [isBulkUpdateOpen, setIsBulkUpdateOpen] = useState(false)
  const [bulkStatus, setBulkStatus] = useState("")
  const [updatingBulk, setUpdatingBulk] = useState(false)

  // Identify Role to Filter Data
  const [effectiveEmail, setEffectiveEmail] = useState<string | null>(null)
  useEffect(() => {
    setEffectiveEmail(user?.email || (typeof window !== 'undefined' ? sessionStorage.getItem("ghaLink_guest_email") : null))
  }, [user])

  const clientsRef = useMemoFirebase(() => db ? collection(db, 'clients') : null, [db])
  const clientMatchQuery = useMemoFirebase(() => {
    if (!clientsRef || !effectiveEmail) return null
    return query(clientsRef, where('email', '==', effectiveEmail), limit(1))
  }, [clientsRef, effectiveEmail])
  
  const { data: clientRecord, loading: loadingIdentity } = useCollection(clientMatchQuery)

  const clientData = useMemo(() => {
    if (clientRecord && clientRecord.length > 0) return clientRecord[0]
    if (effectiveEmail === "demo@client.com") return { id: "demo-uid" }
    return null
  }, [clientRecord, effectiveEmail])

  const isClient = !!clientData

  // Data Fetching based on Role - use clientData.id for stable memoization
  const shipmentsRef = useMemoFirebase(() => {
    if (!db) return null
    const base = collection(db, 'shipments')
    if (isClient && clientData?.id) {
      return query(base, where('clientId', '==', clientData.id))
    }
    return base
  }, [db, isClient, clientData?.id])
  
  const { data: shipments, loading } = useCollection(shipmentsRef)

  const filteredShipments = (shipments || []).filter(s => 
    s.trackingId?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    s.clientName?.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const toggleSelect = (id: string) => {
    setSelectedShipments(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    )
  }

  const handleBulkUpdate = async () => {
    if (!db || !bulkStatus || selectedShipments.length === 0) return
    setUpdatingBulk(true)

    const promises = selectedShipments.map(id => {
      const milestone = {
        status: bulkStatus,
        timestamp: new Date().toISOString(),
        location: "Logistics Hub",
        note: `Bulk update: shipment moved to ${bulkStatus}. Client auto-notified.`
      }
      return updateDoc(doc(db, 'shipments', id), {
        status: bulkStatus,
        updatedAt: serverTimestamp(),
        milestones: arrayUnion(milestone)
      })
    })

    try {
      await Promise.all(promises)
      toast({
        title: "Bulk Update Successful",
        description: `${selectedShipments.length} shipments updated to ${bulkStatus}. Clients notified.`,
      })
      setSelectedShipments([])
      setIsBulkUpdateOpen(false)
    } catch (e) {
      toast({ variant: "destructive", title: "Bulk Update Failed" })
    } finally {
      setUpdatingBulk(false)
    }
  }

  const handleDelete = async (id: string) => {
    if (!db || !confirm("Delete this shipment?")) return
    try {
      await deleteDoc(doc(db, 'shipments', id))
      toast({ title: "Shipment Deleted" })
    } catch (e) {
      toast({ variant: "destructive", title: "Error" })
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-3xl font-headline font-bold text-primary italic uppercase tracking-tighter">
              {isClient ? "My Cargo Registry" : "Global Shipment Management"}
            </h2>
            <p className="text-muted-foreground mt-1 uppercase text-[10px] font-bold tracking-widest">
              Reliable • Efficient • Trusted • {isClient ? "Manage your consignments" : "Manage all global movements"}
            </p>
          </div>
          <div className="flex gap-2">
            {!isClient && selectedShipments.length > 0 && (
              <Button 
                onClick={() => setIsBulkUpdateOpen(true)}
                className="bg-accent hover:bg-accent/90 shadow-lg font-bold uppercase italic tracking-wider animate-in fade-in zoom-in"
              >
                <Megaphone className="mr-2 h-4 w-4" /> Bulk Notify ({selectedShipments.length})
              </Button>
            )}
            {!isClient && (
              <Button asChild className="bg-primary hover:bg-primary/90 shadow-lg border-b-4 border-primary/50 font-bold uppercase italic tracking-wider">
                <Link href="/shipments/new">
                  <Plus className="mr-2 h-4 w-4" /> New Shipment
                </Link>
              </Button>
            )}
          </div>
        </div>

        <Card className="border-none shadow-sm">
          <CardHeader className="p-4 md:p-6 pb-0">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
              <div className="relative w-full md:w-96">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Search tracking number..." 
                  className="pl-9 bg-muted/50 border-none"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="flex gap-2 w-full md:w-auto">
                <Button variant="outline" size="sm" className="flex-1 md:flex-none font-bold uppercase text-[10px] tracking-widest">
                  <Filter className="mr-2 h-4 w-4" /> Filter
                </Button>
                {!isClient && (
                  <Button variant="outline" size="sm" className="flex-1 md:flex-none font-bold uppercase text-[10px] tracking-widest">
                    Export CSV
                  </Button>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0 mt-6">
            {loading || loadingIdentity ? (
              <div className="flex justify-center p-8"><Loader2 className="animate-spin text-primary" /></div>
            ) : (
              <Table>
                <TableHeader className="bg-muted/30">
                  <TableRow>
                    {!isClient && <TableHead className="w-[50px]"></TableHead>}
                    <TableHead className="font-bold uppercase text-[10px]">Tracking ID</TableHead>
                    {!isClient && <TableHead className="font-bold uppercase text-[10px]">Client</TableHead>}
                    <TableHead className="font-bold uppercase text-[10px]">Route</TableHead>
                    <TableHead className="font-bold uppercase text-[10px]">Method</TableHead>
                    <TableHead className="font-bold uppercase text-[10px]">Weight</TableHead>
                    <TableHead className="font-bold uppercase text-[10px]">Status</TableHead>
                    <TableHead className="text-right font-bold uppercase text-[10px]">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredShipments.map((shipment) => (
                    <TableRow key={shipment.id} className={`group hover:bg-muted/10 transition-colors ${selectedShipments.includes(shipment.id) ? 'bg-primary/5' : ''}`}>
                      {!isClient && (
                        <TableCell>
                          <Checkbox 
                            checked={selectedShipments.includes(shipment.id)} 
                            onCheckedChange={() => toggleSelect(shipment.id)}
                            className="border-primary/20 data-[state=checked]:bg-primary"
                          />
                        </TableCell>
                      )}
                      <TableCell className="font-black italic text-primary uppercase tracking-tighter">{shipment.trackingId}</TableCell>
                      {!isClient && <TableCell className="font-medium text-xs uppercase">{shipment.clientName || 'Unknown'}</TableCell>}
                      <TableCell className="text-[11px] font-bold">
                        {shipment.origin?.split(' ')[0]} → {shipment.destination?.split(' ')[0]}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="font-bold border-primary/20 text-primary text-[10px] uppercase">
                          {shipment.method}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-bold text-xs">{shipment.weight}kg</TableCell>
                      <TableCell>
                        <Badge 
                          className={
                            shipment.status === "Delivered" ? "bg-emerald-100 text-emerald-700 border-emerald-200" :
                            shipment.status === "In Transit" ? "bg-primary text-white border-primary" :
                            shipment.status === "Customs" ? "bg-accent text-white border-accent" :
                            "bg-secondary text-secondary-foreground"
                          }
                        >
                          {shipment.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button variant="ghost" size="icon" asChild title="View Details">
                            <Link href={`/shipments/${shipment.id}`}>
                              <Eye className="h-4 w-4 text-primary" />
                            </Link>
                          </Button>
                          {!isClient && (
                            <Button variant="ghost" size="icon" className="text-destructive hover:bg-destructive/10" onClick={() => handleDelete(shipment.id)} title="Delete">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
            {!loading && filteredShipments.length === 0 && (
              <div className="flex flex-col items-center justify-center p-12 text-center text-muted-foreground">
                <Ship className="h-12 w-12 mb-4 opacity-10" />
                <p className="font-bold uppercase text-[10px] tracking-widest">No consignments found matching your query.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={isBulkUpdateOpen} onOpenChange={setIsBulkUpdateOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-primary italic uppercase tracking-tighter">Bulk Consignee Notification</DialogTitle>
            <DialogDescription className="text-[10px] uppercase font-bold tracking-widest">Update status and notify {selectedShipments.length} shippers.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
             <div className="space-y-2">
                <Label className="text-[10px] font-bold uppercase">Target Status</Label>
                <Select value={bulkStatus} onValueChange={setBulkStatus}>
                   <SelectTrigger className="h-12 font-black italic uppercase">
                      <SelectValue placeholder="Select new status..." />
                   </SelectTrigger>
                   <SelectContent>
                      <SelectItem value="Warehouse">Warehouse (China)</SelectItem>
                      <SelectItem value="In Transit">In Transit</SelectItem>
                      <SelectItem value="Customs">Customs (Ghana)</SelectItem>
                      <SelectItem value="Delivered">Delivered</SelectItem>
                   </SelectContent>
                </Select>
             </div>
             <div className="p-4 rounded-lg bg-accent/5 border border-accent/20">
                <p className="text-xs font-medium text-primary italic">
                  Note: Updating status will automatically append a milestone to each shipment and trigger an automated in-app/email alert to the clients.
                </p>
             </div>
          </div>
          <DialogFooter>
             <Button variant="outline" onClick={() => setIsBulkUpdateOpen(false)}>Cancel</Button>
             <Button 
                onClick={handleBulkUpdate} 
                disabled={updatingBulk || !bulkStatus} 
                className="bg-primary text-white font-black italic uppercase"
              >
                {updatingBulk ? <Loader2 className="animate-spin mr-2 h-4 w-4" /> : <Megaphone className="mr-2 h-4 w-4" />}
                Confirm & Dispatch
             </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  )
}
