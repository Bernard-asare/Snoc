
"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Package, Loader2, Plus, Trash2 } from "lucide-react"
import { useState, useEffect } from "react"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import { useCollection, useFirestore, useMemoFirebase } from "@/firebase"
import { collection, addDoc, serverTimestamp } from "firebase/firestore"
import { errorEmitter } from "@/firebase/error-emitter"
import { FirestorePermissionError } from "@/firebase/errors"

export default function NewShipmentPage() {
  const { toast } = useToast()
  const router = useRouter()
  const db = useFirestore()
  const [loading, setLoading] = useState(false)
  const [mounted, setMounted] = useState(false)
  
  const clientsRef = useMemoFirebase(() => db ? collection(db, 'clients') : null, [db])
  const { data: clients } = useCollection(clientsRef)

  const [formData, setFormData] = useState({
    trackingId: "",
    clientId: "",
    origin: "Shenzhen Hub",
    destination: "Tema Port",
    method: "Sea",
    weight: 0,
    volume: 0,
    declaredValue: 0,
    date: "",
    status: "Warehouse",
    items: [{ description: "", quantity: 1, valuePerItem: 0, hsCode: "8517.13" }]
  })

  useEffect(() => {
    setMounted(true)
    // Safe initialization after mount to prevent hydration mismatch
    setFormData(prev => ({
      ...prev,
      trackingId: "GL-" + Math.floor(1000 + Math.random() * 9000),
      date: new Date().toISOString().split('T')[0]
    }))
  }, [])

  const addItem = () => setFormData(prev => ({ ...prev, items: [...prev.items, { description: "", quantity: 1, valuePerItem: 0, hsCode: "" }] }))
  const removeItem = (idx: number) => setFormData(prev => ({ ...prev, items: prev.items.filter((_, i) => i !== idx) }))
  const updateItem = (idx: number, field: string, val: any) => {
    const newItems = [...formData.items]
    newItems[idx] = { ...newItems[idx], [field]: val }
    setFormData(prev => ({ ...prev, items: newItems }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!db || !formData.clientId) {
      toast({ variant: "destructive", title: "Client Required", description: "Select a consignee." })
      return
    }

    setLoading(true)
    const selectedClient = clients?.find(c => c.id === formData.clientId)
    const payload = { 
      ...formData, 
      clientName: selectedClient?.name || 'Unknown', 
      createdAt: serverTimestamp() 
    }

    addDoc(collection(db, 'shipments'), payload)
      .then(() => {
        toast({ title: "Cargo Registered", description: `Shipment ${formData.trackingId} logged.` })
        router.push("/shipments")
      })
      .catch(async (err) => {
        const permissionError = new FirestorePermissionError({ 
          path: 'shipments', 
          operation: 'create', 
          requestResourceData: payload 
        })
        errorEmitter.emit('permission-error', permissionError)
        setLoading(false)
      })
  }

  if (!mounted) return null

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between border-b pb-6">
          <div>
            <h2 className="text-3xl font-headline font-black italic text-primary uppercase tracking-tighter">Cargo Registry</h2>
            <p className="text-muted-foreground font-bold uppercase text-[10px] tracking-widest">New Consignment Entry</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Card className="border-none shadow-sm overflow-hidden">
            <CardHeader className="bg-primary text-white">
              <CardTitle className="flex items-center gap-2 italic uppercase tracking-tighter"><Package className="h-5 w-5 text-accent" /> Shipment Details</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-6 pt-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase font-bold text-muted-foreground">Consignee</Label>
                  <Select value={formData.clientId} onValueChange={(v) => setFormData({...formData, clientId: v})}>
                    <SelectTrigger><SelectValue placeholder="Select Client..." /></SelectTrigger>
                    <SelectContent>
                      {(clients || []).map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase font-bold text-muted-foreground">Tracking ID</Label>
                  <Input value={formData.trackingId} readOnly className="bg-muted font-black" />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase font-bold text-muted-foreground">Origin Port</Label>
                  <Input value={formData.origin} onChange={e => setFormData({...formData, origin: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase font-bold text-muted-foreground">Destination Hub</Label>
                  <Input value={formData.destination} onChange={e => setFormData({...formData, destination: e.target.value})} />
                </div>
              </div>

              <div className="space-y-4 pt-4 border-t">
                <div className="flex justify-between items-center">
                  <Label className="text-[10px] font-black uppercase tracking-widest text-primary">Itemized Inventory</Label>
                  <Button type="button" variant="outline" size="sm" onClick={addItem}><Plus className="h-3 w-3 mr-1" /> Add</Button>
                </div>
                {formData.items.map((item, idx) => (
                  <div key={idx} className="flex gap-2 items-end border p-3 rounded-lg bg-muted/20 relative group">
                    <div className="flex-1 space-y-1">
                      <Label className="text-[8px] uppercase">Description</Label>
                      <Input className="h-8 text-xs" value={item.description} onChange={e => updateItem(idx, 'description', e.target.value)} />
                    </div>
                    <div className="w-16 space-y-1">
                      <Label className="text-[8px] uppercase">Qty</Label>
                      <Input className="h-8 text-xs" type="number" value={item.quantity} onChange={e => updateItem(idx, 'quantity', Number(e.target.value))} />
                    </div>
                    <div className="w-20 space-y-1">
                      <Label className="text-[8px] uppercase">Val/ea</Label>
                      <Input className="h-8 text-xs" type="number" value={item.valuePerItem} onChange={e => updateItem(idx, 'valuePerItem', Number(e.target.value))} />
                    </div>
                    <Button type="button" variant="ghost" size="icon" className="text-destructive group-hover:opacity-100 opacity-0" onClick={() => removeItem(idx)}>
                      <Trash2 size={14}/>
                    </Button>
                  </div>
                ))}
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase font-bold">Total Weight (kg)</Label>
                  <Input type="number" value={formData.weight || ""} onChange={e => setFormData({...formData, weight: Number(e.target.value)})} />
                </div>
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase font-bold">Total Volume (CBM)</Label>
                  <Input type="number" value={formData.volume || ""} onChange={e => setFormData({...formData, volume: Number(e.target.value)})} />
                </div>
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase font-bold">Shipment Method</Label>
                  <Select value={formData.method} onValueChange={v => setFormData({...formData, method: v})}>
                    <SelectTrigger><SelectValue/></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Sea">Sea Freight</SelectItem>
                      <SelectItem value="Air">Air Freight</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
          <div className="flex justify-end gap-3">
            <Button variant="outline" type="button" onClick={() => router.back()}>Cancel</Button>
            <Button type="submit" className="bg-primary h-12 px-8 font-black italic uppercase" disabled={loading}>
              {loading ? <Loader2 className="animate-spin mr-2"/> : null} Register Cargo
            </Button>
          </div>
        </form>
      </div>
    </DashboardLayout>
  )
}
