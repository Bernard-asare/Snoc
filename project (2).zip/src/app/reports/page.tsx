
"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from "@/components/ui/table"
import { useCollection, useFirestore, useMemoFirebase, useUser } from "@/firebase"
import { collection, query, where, orderBy, limit } from "firebase/firestore"
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, LineChart, Line
} from "recharts"
import { 
  TrendingUp, Download, Receipt, DollarSign, 
  ArrowUpRight, ArrowDownRight, FileText, Loader2,
  Calendar, PieChart as PieIcon, CreditCard
} from "lucide-react"
import { useState, useMemo, useEffect } from "react"
import { format, subMonths, startOfMonth, endOfMonth, isWithinInterval } from "date-fns"

export default function ReportsPage() {
  const db = useFirestore()
  const { user } = useUser()
  const [mounted, setMounted] = useState(false)

  // Identify Role
  const [effectiveEmail, setEffectiveEmail] = useState<string | null>(null)
  useEffect(() => {
    setMounted(true)
    setEffectiveEmail(user?.email || (typeof window !== 'undefined' ? sessionStorage.getItem("ghaLink_guest_email") : null))
  }, [user])

  const clientsRef = useMemoFirebase(() => db ? collection(db, 'clients') : null, [db])
  const clientMatchQuery = useMemoFirebase(() => {
    if (!clientsRef || !effectiveEmail) return null
    return query(clientsRef, where('email', '==', effectiveEmail), limit(1))
  }, [clientsRef, effectiveEmail])
  
  const { data: clientRecord } = useCollection(clientMatchQuery)

  const clientData = useMemo(() => {
    if (clientRecord && clientRecord.length > 0) return clientRecord[0]
    if (effectiveEmail === "demo@client.com") return { name: "Demo Client", id: "demo-uid" }
    return null
  }, [clientRecord, effectiveEmail])

  const isClient = !!clientData

  // Data Fetching
  const invoicesRef = useMemoFirebase(() => db ? collection(db, 'invoices') : null, [db])
  const roleInvoicesQuery = useMemoFirebase(() => {
    if (!invoicesRef) return null
    if (isClient && clientData?.name) {
      return query(invoicesRef, where('billedTo.name', '==', clientData.name), orderBy('date', 'desc'))
    }
    return query(invoicesRef, orderBy('date', 'desc'))
  }, [invoicesRef, isClient, clientData?.name])
  
  const { data: invoices, loading: loadingInvoices } = useCollection(roleInvoicesQuery)

  // Calculations
  const stats = useMemo(() => {
    if (!invoices) return null
    const totalRevenue = invoices.reduce((acc, inv) => acc + (inv.total || 0), 0)
    const paidRevenue = invoices.filter(i => i.status === "Paid").reduce((acc, inv) => acc + (inv.total || 0), 0)
    const pendingRevenue = invoices.filter(i => i.status !== "Paid").reduce((acc, inv) => acc + (inv.total || 0), 0)
    
    return {
      total: totalRevenue,
      paid: paidRevenue,
      pending: pendingRevenue,
      count: invoices.length
    }
  }, [invoices])

  const chartData = useMemo(() => {
    if (!invoices) return []
    const months = Array.from({ length: 6 }).map((_, i) => {
      const d = subMonths(new Date(), 5 - i)
      return {
        name: format(d, 'MMM'),
        revenue: 0,
        paid: 0
      }
    })

    invoices.forEach(inv => {
      const invDate = new Date(inv.date)
      const invMonth = format(invDate, 'MMM')
      const target = months.find(m => m.name === invMonth)
      if (target) {
        target.revenue += (inv.total || 0)
        if (inv.status === "Paid") target.paid += (inv.total || 0)
      }
    })
    return months
  }, [invoices])

  const exportCSV = () => {
    if (!invoices) return
    const headers = ["Invoice #", "Date", "Status", "Amount", "Client"]
    const rows = invoices.map(i => [i.invoiceNumber, i.date, i.status, i.total, i.billedTo?.name])
    const csvContent = "data:text/csv;charset=utf-8," + 
      [headers.join(","), ...rows.map(r => r.join(","))].join("\n")
    const encodedUri = encodeURI(csvContent)
    const link = document.createElement("a")
    link.setAttribute("href", encodedUri)
    link.setAttribute("download", `snoc_financial_report_${format(new Date(), 'yyyy-MM-dd')}.csv`)
    document.body.appendChild(link)
    link.click()
  }

  if (!mounted || loadingInvoices) {
    return <DashboardLayout><div className="flex justify-center p-20"><Loader2 className="animate-spin h-8 w-8 text-primary" /></div></DashboardLayout>
  }

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b pb-6">
          <div className="space-y-1">
            <h2 className="text-4xl font-headline font-black tracking-tighter italic text-primary uppercase">
              {isClient ? "Financial Statement" : "Executive Financial Hub"}
            </h2>
            <p className="text-muted-foreground font-bold uppercase tracking-widest text-[10px]">
              Reliable • Efficient • Trusted • Financial Performance Indicators
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="h-12 font-bold uppercase italic tracking-wider border-primary/20" onClick={exportCSV}>
              <Download className="mr-2 h-4 w-4" /> Export Report
            </Button>
            {!isClient && (
              <Button className="bg-primary hover:bg-primary/90 shadow-lg h-12 font-bold uppercase italic tracking-wider">
                <CreditCard className="mr-2 h-4 w-4" /> Process Payments
              </Button>
            )}
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card className="border-none shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="p-3 rounded-xl bg-primary/10 text-primary">
                  <DollarSign size={24} />
                </div>
                <Badge className="bg-emerald-100 text-emerald-700 border-none font-bold uppercase text-[8px]">
                  Verified Revenue
                </Badge>
              </div>
              <div className="mt-4">
                <p className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">
                  {isClient ? "Total Expenditure" : "Gross Revenue (USD)"}
                </p>
                <p className="text-2xl font-black italic tracking-tight">${stats?.total.toLocaleString()}</p>
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-none shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="p-3 rounded-xl bg-accent/10 text-accent">
                  <CreditCard size={24} />
                </div>
                <Badge className="bg-primary text-white font-bold uppercase text-[8px]">
                  Settled
                </Badge>
              </div>
              <div className="mt-4">
                <p className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">
                  Total Paid
                </p>
                <p className="text-2xl font-black italic tracking-tight text-primary">${stats?.paid.toLocaleString()}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="p-3 rounded-xl bg-orange-100 text-orange-600">
                  <Receipt size={24} />
                </div>
                <Badge className="bg-orange-100 text-orange-700 font-bold uppercase text-[8px]">
                  Outstanding
                </Badge>
              </div>
              <div className="mt-4">
                <p className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">
                  Pending Balance
                </p>
                <p className="text-2xl font-black italic tracking-tight text-orange-600">${stats?.pending.toLocaleString()}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="p-3 rounded-xl bg-primary/5 text-primary">
                  <FileText size={24} />
                </div>
                <div className="text-[10px] font-black uppercase text-primary">
                  {stats?.count} Records
                </div>
              </div>
              <div className="mt-4">
                <p className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">
                  Transaction Count
                </p>
                <p className="text-2xl font-black italic tracking-tight">{stats?.count}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
          <Card className="lg:col-span-4 border-none shadow-sm">
            <CardHeader>
              <CardTitle className="text-primary italic uppercase tracking-tighter">Revenue Analysis</CardTitle>
              <CardDescription className="text-[10px] uppercase font-bold tracking-widest">Historical monthly performance and collection efficiency.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[350px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(0,0,0,0.05)" />
                    <XAxis dataKey="name" fontSize={10} axisLine={false} tickLine={false} />
                    <YAxis fontSize={10} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v}`} />
                    <Tooltip 
                      cursor={{fill: 'rgba(26,54,93,0.05)'}} 
                      contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                    />
                    <Bar name="Gross Revenue" dataKey="revenue" fill="#1a365d" radius={[4, 4, 0, 0]} />
                    <Bar name="Paid Amount" dataKey="paid" fill="#e11d48" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card className="lg:col-span-3 border-none shadow-sm">
            <CardHeader>
              <CardTitle className="text-primary italic uppercase tracking-tighter">Collection Health</CardTitle>
              <CardDescription className="text-[10px] uppercase font-bold tracking-widest">Percentage of settled vs outstanding dues.</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center">
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie 
                      data={[
                        { name: 'Paid', value: stats?.paid || 0, color: '#1a365d' },
                        { name: 'Pending', value: stats?.pending || 0, color: '#e11d48' }
                      ]} 
                      cx="50%" cy="50%" innerRadius={70} outerRadius={90} dataKey="value" paddingAngle={5}
                    >
                      <Cell fill="#1a365d" />
                      <Cell fill="#e11d48" />
                    </Pie>
                    <Tooltip />
                    <Legend verticalAlign="bottom" height={36}/>
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="text-center mt-4">
                <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Collection Rate</p>
                <p className="text-3xl font-black italic text-primary">
                  {stats?.total ? Math.round((stats.paid / stats.total) * 100) : 0}%
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Ledger Section */}
        <Card className="border-none shadow-sm overflow-hidden">
          <CardHeader className="bg-primary text-white border-b-4 border-accent">
            <CardTitle className="italic uppercase tracking-tighter">Financial Ledger</CardTitle>
            <CardDescription className="text-white/60 text-[10px] uppercase font-bold tracking-widest">
              Detailed chronological record of all commercial transactions.
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            {invoices && invoices.length > 0 ? (
              <Table>
                <TableHeader className="bg-muted/30">
                  <TableRow>
                    <TableHead className="font-bold uppercase text-[10px]">Invoice #</TableHead>
                    <TableHead className="font-bold uppercase text-[10px]">Date</TableHead>
                    <TableHead className="font-bold uppercase text-[10px]">Consignee</TableHead>
                    <TableHead className="font-bold uppercase text-[10px]">Method</TableHead>
                    <TableHead className="font-bold uppercase text-[10px]">Status</TableHead>
                    <TableHead className="text-right font-bold uppercase text-[10px]">Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {invoices.map((inv) => (
                    <TableRow key={inv.id} className="hover:bg-primary/5 transition-colors">
                      <TableCell className="font-black italic text-primary uppercase">{inv.invoiceNumber}</TableCell>
                      <TableCell className="text-xs font-medium">{inv.date}</TableCell>
                      <TableCell className="text-xs font-bold uppercase">{inv.billedTo?.name || 'N/A'}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-[9px] font-black uppercase tracking-tighter italic border-primary/20">
                          {inv.shipmentDetails?.method || 'Freight'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={
                          inv.status === "Paid" ? "bg-emerald-100 text-emerald-700" :
                          inv.status === "Overdue" ? "bg-red-100 text-red-700" :
                          "bg-orange-100 text-orange-700"
                        }>
                          {inv.status || 'Sent'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right font-black italic text-primary">${inv.total?.toLocaleString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="p-20 text-center text-muted-foreground uppercase font-black text-[10px] tracking-widest opacity-20">
                No financial records detected in the SNOC ledger.
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
