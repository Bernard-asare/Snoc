
"use client"

import { useState } from "react"
import { signInWithPopup, GoogleAuthProvider } from "firebase/auth"
import { useAuth, useFirestore } from "@/firebase"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Ship, Plane, Truck, Loader2, UserCircle, ShieldCheck, Key, ArrowRight, AlertCircle } from "lucide-react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { collection, query, where, getDocs, limit } from "firebase/firestore"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function LoginPage() {
  const auth = useAuth()
  const db = useFirestore()
  const router = useRouter()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [clientLoading, setClientLoading] = useState(false)

  const handleLogin = async () => {
    setLoading(true)
    const provider = new GoogleAuthProvider()
    try {
      await signInWithPopup(auth, provider)
      router.push("/")
      toast({ title: "Welcome back!", description: "Successfully signed in to SNOC LOGISTICS AND CARGO Admin Portal." })
    } catch (error) {
      toast({ 
        variant: "destructive", 
        title: "Login Failed", 
        description: "Could not authenticate. Ensure your project configuration is correct." 
      })
    } finally {
      setLoading(false)
    }
  }

  const handleClientAccess = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setClientLoading(true)
    const formData = new FormData(e.currentTarget)
    const email = formData.get('email') as string
    const code = formData.get('code') as string

    try {
      // 1. Verify Client Credentials
      const clientQuery = query(
        collection(db, "clients"),
        where("email", "==", email.toLowerCase().trim()),
        where("accessCode", "==", code.trim()),
        limit(1)
      )

      const clientSnapshot = await getDocs(clientQuery)
      
      if (clientSnapshot.empty) {
        toast({
          variant: "destructive",
          title: "Access Denied",
          description: "Invalid email or tracking passcode."
        })
        setClientLoading(false)
        return
      }

      const clientDoc = clientSnapshot.docs[0]
      const clientName = clientDoc.data().name

      // 2. Strict Check: Verify Payment Status
      // The client can only enter if they have at least one PAID invoice
      const invoiceQuery = query(
        collection(db, "invoices"),
        where("billedTo.name", "==", clientName),
        where("status", "==", "Paid"),
        limit(1)
      )
      
      const invoiceSnapshot = await getDocs(invoiceQuery)

      if (invoiceSnapshot.empty) {
        toast({
          variant: "destructive",
          title: "Access Restricted",
          description: "Your portal access is generated only after your first invoice is confirmed as PAID."
        })
      } else {
        sessionStorage.setItem("ghaLink_guest", "true")
        sessionStorage.setItem("ghaLink_guest_email", email.toLowerCase().trim())
        router.push("/")
        toast({ title: "Welcome to Snoc Hub", description: "Payment verified. Access granted." })
      }
    } catch (err) {
      toast({ variant: "destructive", title: "System Error", description: "Failed to verify credentials." })
    } finally {
      setClientLoading(false)
    }
  }

  const handleGuestLogin = () => {
    sessionStorage.setItem("ghaLink_guest", "true")
    sessionStorage.removeItem("ghaLink_guest_email")
    router.push("/")
    toast({ title: "Admin Access (Guest)", description: "You are now accessing the portal as a guest administrator." })
  }

  return (
    <div className="min-h-screen bg-muted/30 flex items-center justify-center p-4 font-body">
      <Card className="w-full max-w-md border-none shadow-2xl overflow-hidden bg-white">
        <CardHeader className="bg-primary text-primary-foreground text-center py-10 relative border-b-4 border-accent">
          <div className="absolute top-4 right-4 opacity-10">
            <ShieldCheck size={64} />
          </div>
          <div className="flex justify-center mb-6 gap-3">
            <div className="bg-white/10 rounded-xl p-2 backdrop-blur-sm border border-white/20">
              <Plane size={24} className="text-accent" />
            </div>
            <div className="bg-white/10 rounded-xl p-2 backdrop-blur-sm border border-white/20">
              <Ship size={24} className="text-white" />
            </div>
            <div className="bg-white/10 rounded-xl p-2 backdrop-blur-sm border border-white/20">
              <Truck size={24} className="text-white" />
            </div>
          </div>
          <CardTitle className="text-4xl font-headline font-black tracking-tighter uppercase italic leading-tight">
            SNOC
            <span className="block text-xl font-bold tracking-[0.1em] mt-1 text-accent">LOGISTICS AND CARGO</span>
          </CardTitle>
          <CardDescription className="text-primary-foreground/80 font-medium text-xs mt-3 uppercase tracking-widest">
            Connecting China to Ghana
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-8">
          <Tabs defaultValue="client" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8 bg-muted/50 p-1">
              <TabsTrigger value="client" className="text-[10px] uppercase font-bold tracking-widest data-[state=active]:bg-primary data-[state=active]:text-white">Client Portal</TabsTrigger>
              <TabsTrigger value="staff" className="text-[10px] uppercase font-bold tracking-widest data-[state=active]:bg-primary data-[state=active]:text-white">Staff Login</TabsTrigger>
            </TabsList>
            
            <TabsContent value="client" className="space-y-6">
              <div className="text-center space-y-1 mb-6">
                <h4 className="font-bold text-lg text-primary uppercase italic tracking-tight">Cargo Tracking Hub</h4>
                <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">Access granted after verified payment.</p>
              </div>

              <form onSubmit={handleClientAccess} className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase font-bold text-muted-foreground ml-1">Registered Email</Label>
                  <Input name="email" type="email" placeholder="email@example.com" required className="h-12 border-primary/10" />
                </div>
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase font-bold text-muted-foreground ml-1">Tracking Passcode</Label>
                  <Input name="code" type="password" placeholder="••••••" required className="h-12 border-primary/10" />
                </div>
                <Button 
                  type="submit" 
                  disabled={clientLoading}
                  className="w-full bg-accent hover:bg-accent/90 text-white font-black italic uppercase tracking-wider h-14 shadow-lg group"
                >
                  {clientLoading ? <Loader2 className="animate-spin mr-2" /> : <Key className="mr-2 h-5 w-5" />}
                  Enter Secure Hub
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </form>

              <div className="p-4 rounded-lg bg-primary/5 border border-primary/10 flex gap-3 items-start">
                 <AlertCircle size={16} className="text-primary shrink-0 mt-0.5" />
                 <p className="text-[10px] font-medium text-primary/70 italic leading-relaxed">
                   Login credentials are provided by Snoc Logistics once your first shipment is registered and initial payment is confirmed.
                 </p>
              </div>
            </TabsContent>

            <TabsContent value="staff" className="space-y-6">
              <div className="text-center space-y-1 mb-6">
                <h4 className="font-bold text-lg text-primary uppercase italic tracking-tight">Personnel Access</h4>
                <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest italic">Authorized Snoc Staff Only</p>
              </div>
              
              <Button 
                className="w-full h-14 text-md font-bold shadow-lg bg-primary hover:bg-primary/90 transition-all uppercase tracking-wide italic" 
                onClick={handleLogin} 
                disabled={loading}
              >
                {loading ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <UserCircle className="mr-2 h-5 w-5" />}
                Sign in as Staff
              </Button>
              
              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-muted" />
                </div>
                <div className="relative flex justify-center text-[10px] uppercase font-bold tracking-widest">
                  <span className="bg-white px-3 text-muted-foreground/60">or access demo</span>
                </div>
              </div>

              <Button 
                variant="outline" 
                className="w-full h-12 border-2 border-primary/20 hover:bg-muted/50 font-bold text-primary text-[10px] uppercase italic tracking-widest" 
                onClick={handleGuestLogin}
              >
                <ShieldCheck className="mr-2 h-4 w-4" />
                Enter as Guest Admin
              </Button>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="justify-center border-t py-6 bg-muted/5">
          <p className="text-[10px] text-muted-foreground text-center uppercase font-bold tracking-tight">
            Reliable • Efficient • Trusted
          </p>
        </CardFooter>
      </Card>
    </div>
  )
}
