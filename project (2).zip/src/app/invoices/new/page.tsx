
"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useCollection, useFirestore, useMemoFirebase } from "@/firebase"
import { collection, addDoc } from "firebase/firestore"
import { useRouter } from "next/navigation"
import { useState, useEffect } from "react"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Plus, Trash2 } from "lucide-react"
import { errorEmitter } from "@/firebase/error-emitter"
import { FirestorePermissionError } from "@/firebase/errors"

export default function NewInvoicePage() {
  const db = useFirestore()
  const router = useRouter()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [mounted, setMounted] = useState(false)

  const shipmentsRef = useMemoFirebase(() => db ? collection(db, 'shipments') : null, [db])
  const { data: shipments } = useCollection(shipmentsRef)

  const [formData, setFormData] = useState({
    invoiceNumber: "",
    shipmentId: "",
    date: "",
    dueDate: "",
    status: "Sent",
    items: [{ description: "Freight Charges", quantity: 1, rate: 0 }],
    paymentInstructions: "Bank Transfer: Snoc Logistics Ltd | Account: 123456789 | SWIFT: SNOCGHAC",
    shipmentDetails: { method: "Sea" },
    billedTo: { name: "", phone: "", location: "" }
  })

  useEffect(() => {
    setMounted(true)
    const today = new Date().toISOString().split('T')[0]
    const nextWeek = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    setFormData(prev => ({
      ...prev,
      invoiceNumber: "INV-" + Math.floor(100000 + Math.random() * 900000),
      date: today,
      dueDate: nextWeek
    }))
  }, [])

  const handleShipmentChange = (shipId: string) => {
    const shipment = shipments?.find(s => s.id === shipId)
    if (shipment) {
      setFormData(prev => ({
        ...prev,
        shipmentId: shipment.trackingId,
        shipmentDetails: { method: shipment.method },
        billedTo: { 
          name: shipment.clientName, 
          phone: "See registry", 
          location: shipment.destination 
        },
        items: [
          { description: `Freight Charges - ${shipment.method} Cargo (${shipment.trackingId})`, quantity: 1, rate: (shipment.declaredValue || 0) * 0.1 }
        ]
      }))
    }
  }

  const addItem = () => setFormData(prev => ({ ...prev, items: [...prev.items, { description: "", quantity: 1, rate: 0 }] }))
  const removeItem = (idx: number) => setFormData(prev => ({ ...prev, items: prev.items.filter((_, i) => i !== idx) }))
  const updateItem = (idx: number, field: string, val: any) => {
    const newItems = [...formData.items]
    newItems[idx] = { ...newItems[idx], [field]: val }
    setFormData(prev => ({ ...prev, items: newItems }))
  }

  const calculateTotal = () => {
    const subtotal = formData.items.reduce((acc, item) => acc + (item.quantity * item.rate), 0)
    return { subtotal, total: subtotal }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!db || !formData.shipmentId) return

    setLoading(true)
    const { subtotal, total } = calculateTotal()
    const payload = {
      ...formData,
      subtotal,
      tax: 0,
      total,
      createdAt: new Date()
    }
    
    addDoc(collection(db, 'invoices'), payload)
      .then((docRef) => {
        toast({ title: "Invoice Created" })
        router.push(`/invoices/${docRef.id}`)
      })
      .catch(async (err) => {
        const permissionError = new FirestorePermissionError({
          path: 'invoices',
          operation: 'create',
          requestResourceData: payload,
        })
        errorEmitter.emit('permission-error', permissionError)
        setLoading(false)
      })
  }

  if (!mounted) return null

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <h2 className="text-3xl font-headline font-bold italic text-primary uppercase tracking-tighter">Generate New Invoice</h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <Card className="border-none shadow-sm overflow-hidden">
            <CardHeader className="bg-primary text-white">
              <CardTitle className="text-lg italic uppercase">General Information</CardTitle>
            </CardHeader>
            <CardContent className="grid md:grid-cols-2 gap-4 pt-6">
              <div className="space-y-2">
                <Label className="text-[10px] uppercase font-bold">Invoice Number</Label>
                <Input value={formData.invoiceNumber} readOnly className="bg-muted font-bold" />
              </div>
              <div className="space-y-2">
                <Label className="text-[10px] uppercase font-bold">Select Shipment</Label>
                <Select onValueChange={handleShipmentChange}>
                  <SelectTrigger><SelectValue placeholder="Select tracking ID" /></SelectTrigger>
                  <SelectContent>
                    {(shipments || []).map(s => <SelectItem key={s.id} value={s.id}>{s.trackingId} ({s.clientName})</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-[10px] uppercase font-bold">Status</Label>
                <Select value={formData.status} onValueChange={v => setFormData({...formData, status: v})}>
                  <SelectTrigger><SelectValue/></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Draft">Draft</SelectItem>
                    <SelectItem value="Sent">Sent (Unpaid)</SelectItem>
                    <SelectItem value="Paid">Paid</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-[10px] uppercase font-bold">Invoice Date</Label>
                <Input type="date" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between border-b">
              <CardTitle className="text-lg italic uppercase text-primary">Billable Items</CardTitle>
              <Button type="button" variant="outline" size="sm" onClick={addItem} className="text-[10px] uppercase font-bold"><Plus className="h-4 w-4 mr-1" /> Add Item</Button>
            </CardHeader>
            <CardContent className="space-y-4 pt-6">
              {formData.items.map((item, idx) => (
                <div key={idx} className="flex gap-4 items-end border-b pb-4 last:border-0">
                  <div className="flex-1 space-y-2">
                    <Label className="text-[10px] uppercase font-bold">Description</Label>
                    <Input value={item.description} onChange={e => updateItem(idx, 'description', e.target.value)} />
                  </div>
                  <div className="w-24 space-y-2">
                    <Label className="text-[10px] uppercase font-bold">Qty</Label>
                    <Input type="number" value={item.quantity} onChange={e => updateItem(idx, 'quantity', Number(e.target.value))} />
                  </div>
                  <div className="w-32 space-y-2">
                    <Label className="text-[10px] uppercase font-bold">Rate ($)</Label>
                    <Input type="number" value={item.rate} onChange={e => updateItem(idx, 'rate', Number(e.target.value))} />
                  </div>
                  <Button type="button" variant="ghost" size="icon" onClick={() => removeItem(idx)} className="text-destructive mb-1">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>

          <div className="flex justify-end gap-4">
            <Button variant="outline" type="button" onClick={() => router.back()} className="font-bold uppercase italic text-[10px]">Cancel</Button>
            <Button type="submit" disabled={loading} className="bg-primary hover:bg-primary/90 font-black italic uppercase tracking-wider h-12 px-8">
              {loading ? <Loader2 className="animate-spin mr-2 h-4 w-4" /> : null}
              Generate & Record
            </Button>
          </div>
        </form>
      </div>
    </DashboardLayout>
  )
}
