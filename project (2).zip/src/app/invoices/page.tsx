"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from "@/components/ui/table"
import { Search, Plus, Loader2, Eye, Trash2, Receipt, CheckCircle2, Send, Mail, Smartphone } from "lucide-react"
import Link from "next/link"
import { useState, useEffect, useMemo } from "react"
import { useCollection, useFirestore, useMemoFirebase, useUser } from "@/firebase"
import { collection, deleteDoc, doc, query, where, orderBy, limit, updateDoc, serverTimestamp, getDocs } from "firebase/firestore"
import { useToast } from "@/hooks/use-toast"
import { Badge } from "@/components/ui/badge"

export default function InvoicesPage() {
  const db = useFirestore()
  const { user } = useUser()
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [updatingId, setUpdatingId] = useState<string | null>(null)

  const [effectiveEmail, setEffectiveEmail] = useState<string | null>(null)
  useEffect(() => {
    setEffectiveEmail(user?.email || (typeof window !== 'undefined' ? sessionStorage.getItem("ghaLink_guest_email") : null))
  }, [user])

  const clientsRef = useMemoFirebase(() => db ? collection(db, 'clients') : null, [db])
  const clientMatchQuery = useMemoFirebase(() => {
    if (!clientsRef || !effectiveEmail) return null
    return query(clientsRef, where('email', '==', effectiveEmail), limit(1))
  }, [clientsRef, effectiveEmail])
  
  const { data: clientRecord, loading: loadingIdentity } = useCollection(clientMatchQuery)

  const clientData = useMemo(() => {
    if (clientRecord && clientRecord.length > 0) return clientRecord[0]
    if (effectiveEmail === "demo@client.com") return { name: "Demo Client" }
    return null
  }, [clientRecord, effectiveEmail])

  const isClient = !!clientData

  const invoicesRef = useMemoFirebase(() => db ? collection(db, 'invoices') : null, [db])
  const roleInvoicesQuery = useMemoFirebase(() => {
    if (!invoicesRef) return null
    if (isClient && clientData?.name) {
      return query(invoicesRef, where('billedTo.name', '==', clientData.name), orderBy('date', 'desc'))
    }
    return query(invoicesRef, orderBy('date', 'desc'))
  }, [invoicesRef, isClient, clientData?.name])
  
  const { data: invoices, loading } = useCollection(roleInvoicesQuery)

  const filteredInvoices = (invoices || []).filter(inv => 
    inv.invoiceNumber?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    inv.shipmentId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    inv.billedTo?.name?.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const handleMarkAsPaid = async (id: string, invoice: any) => {
    if (!db) return
    setUpdatingId(id)
    try {
      // 1. Update Invoice Status
      await updateDoc(doc(db, 'invoices', id), {
        status: "Paid",
        paidAt: serverTimestamp()
      })

      // 2. Automated Dispatch Logic
      const clientQuery = query(
        collection(db, "clients"),
        where("name", "==", invoice.billedTo.name),
        limit(1)
      )
      const clientSnap = await getDocs(clientQuery)
      
      if (!clientSnap.empty) {
        const client = clientSnap.docs[0].data()
        
        // Simulation of automatic Email/SMS dispatch
        console.log(`[SNOC AUTO-DISPATCH] Success! credentials sent to: ${client.email}`)
        console.log(`[SNOC AUTO-DISPATCH] Credentials for SN-${clientSnap.docs[0].id.substring(0,4)}: Passcode is [${client.accessCode}]`)

        toast({ 
          title: "Payment Confirmed & Dispatched", 
          description: `Temporary login credentials have been sent to ${invoice.billedTo.name}.` 
        })
      } else {
        toast({ title: "Payment Confirmed", description: "The invoice is marked as paid." })
      }

    } catch (e) {
      toast({ variant: "destructive", title: "Update Failed" })
    } finally {
      setUpdatingId(null)
    }
  }

  const handleDelete = async (id: string) => {
    if (!db || !confirm("Delete this invoice record?")) return
    try {
      await deleteDoc(doc(db, 'invoices', id))
      toast({ title: "Invoice Removed" })
    } catch (e) {
      toast({ variant: "destructive", title: "Error" })
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-3xl font-headline font-bold text-primary italic uppercase tracking-tighter">
              {isClient ? "My Billing History" : "Commercial Billing Hub"}
            </h2>
            <p className="text-muted-foreground mt-1 uppercase text-[10px] font-bold tracking-widest">
              Reliable • Efficient • Trusted • Financial Records
            </p>
          </div>
          {!isClient && (
            <Button asChild className="bg-primary hover:bg-primary/90 font-bold uppercase italic tracking-wider">
              <Link href="/invoices/new">
                <Plus className="mr-2 h-4 w-4" /> Generate Invoice
              </Link>
            </Button>
          )}
        </div>

        <Card className="border-none shadow-sm overflow-hidden">
          <CardHeader className="p-4 md:p-6 pb-0 border-b bg-muted/20">
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search invoice #, tracking # or client..." 
                className="pl-9 bg-white border-primary/10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {loading || loadingIdentity ? (
              <div className="flex justify-center p-12"><Loader2 className="animate-spin text-primary h-8 w-8" /></div>
            ) : (
              <Table>
                <TableHeader className="bg-muted/30">
                  <TableRow>
                    <TableHead className="font-bold uppercase text-[10px]">Invoice #</TableHead>
                    {!isClient && <TableHead className="font-bold uppercase text-[10px]">Client</TableHead>}
                    <TableHead className="font-bold uppercase text-[10px]">Consignment ID</TableHead>
                    <TableHead className="font-bold uppercase text-[10px]">Date</TableHead>
                    <TableHead className="font-bold uppercase text-[10px]">Status</TableHead>
                    <TableHead className="text-right font-bold uppercase text-[10px]">Amount</TableHead>
                    <TableHead className="text-right font-bold uppercase text-[10px]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredInvoices.map((inv) => (
                    <TableRow key={inv.id} className="hover:bg-primary/5 group">
                      <TableCell className="font-black italic text-primary uppercase">{inv.invoiceNumber}</TableCell>
                      {!isClient && <TableCell className="text-xs font-bold uppercase">{inv.billedTo?.name}</TableCell>}
                      <TableCell className="font-bold text-xs">{inv.shipmentId}</TableCell>
                      <TableCell className="text-xs">{inv.date}</TableCell>
                      <TableCell>
                        <Badge className={
                          inv.status === "Paid" ? "bg-emerald-100 text-emerald-700" :
                          inv.status === "Overdue" ? "bg-red-100 text-red-700" :
                          "bg-orange-100 text-orange-700"
                        }>
                          {inv.status || 'Sent'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right font-black italic text-primary text-sm">${inv.total?.toLocaleString()}</TableCell>
                      <TableCell className="text-right space-x-1">
                        {!isClient && inv.status !== "Paid" && (
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => handleMarkAsPaid(inv.id, inv)} 
                            disabled={updatingId === inv.id}
                            title="Confirm Payment & Send Credentials"
                            className="text-emerald-600 hover:bg-emerald-50"
                          >
                            {updatingId === inv.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
                          </Button>
                        )}
                        <Button variant="ghost" size="icon" asChild title="View & Print">
                          <Link href={`/invoices/${inv.id}`}>
                            <Eye className="h-4 w-4 text-primary" />
                          </Link>
                        </Button>
                        {!isClient && (
                          <Button variant="ghost" size="icon" className="text-destructive hover:bg-destructive/10" onClick={() => handleDelete(inv.id)} title="Delete">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
            {!loading && filteredInvoices.length === 0 && (
              <div className="p-20 text-center">
                <Receipt className="h-12 w-12 text-muted-foreground/10 mx-auto mb-4" />
                <p className="text-muted-foreground font-bold uppercase text-[10px] tracking-widest">No billing records identified in your hub.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
