"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Button } from "@/components/ui/button"
import { useDoc, useFirestore } from "@/firebase"
import { doc } from "firebase/firestore"
import { useParams, useRouter } from "next/navigation"
import { Printer, ArrowLeft, Plane, Ship, Truck, UserCircle, MapPin, DollarSign } from "lucide-react"
import { useMemo } from "react"

export default function InvoiceDetailPage() {
  const { id } = useParams()
  const db = useFirestore()
  const router = useRouter()
  
  const invoiceRef = useMemo(() => db && id ? doc(db, 'invoices', id as string) : null, [db, id])
  const { data: invoice, loading } = useDoc(invoiceRef)

  const handlePrint = () => {
    window.print()
  }

  if (loading) return <DashboardLayout><div className="flex justify-center p-20"><Printer className="animate-spin h-8 w-8 text-primary" /></div></DashboardLayout>
  if (!invoice) return <DashboardLayout><div>Invoice not found.</div></DashboardLayout>

  return (
    <DashboardLayout>
      <div className="mb-8 flex items-center justify-between no-print">
        <Button variant="ghost" onClick={() => router.back()}><ArrowLeft className="mr-2 h-4 w-4" /> Back</Button>
        <Button onClick={handlePrint} className="bg-primary hover:bg-primary/90"><Printer className="mr-2 h-4 w-4" /> Print Invoice</Button>
      </div>

      <div className="bg-white text-black p-0 md:p-12 shadow-2xl max-w-[900px] mx-auto min-h-[1100px] flex flex-col relative print:shadow-none print:p-0">
        
        <div className="flex justify-between items-start mb-12">
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              <div className="bg-primary rounded-lg p-2 text-white">
                <Plane size={32} className="stroke-[3px]" />
              </div>
              <div>
                <h1 className="font-headline font-black text-4xl leading-none italic tracking-tighter text-primary">SNOC</h1>
                <p className="text-sm text-accent uppercase tracking-[0.1em] font-black mt-1">LOGISTICS AND CARGO</p>
              </div>
            </div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground mt-2 border-t pt-1">
              Importation • Freight Forwarding • Warehousing • Distribution
            </p>
            <p className="text-[10px] font-bold text-accent uppercase tracking-widest">
              Connecting Ghana to Global — Reliable. Efficient. Trusted.
            </p>
          </div>

          <div className="text-right">
            <h2 className="text-6xl font-black text-primary italic uppercase tracking-tighter opacity-10 absolute right-12 top-12 pointer-events-none">INVOICE</h2>
            <div className="bg-primary text-white p-4 rounded-bl-3xl shadow-lg relative z-10">
              <h2 className="text-3xl font-black italic tracking-tighter">INVOICE</h2>
            </div>
            <div className="mt-6 space-y-2 text-sm font-medium">
              <div className="flex justify-end gap-4"><span className="text-muted-foreground uppercase text-[10px] font-bold tracking-widest">Invoice Number:</span> <span className="border-b border-black/20 min-w-[150px]">{invoice.invoiceNumber}</span></div>
              <div className="flex justify-end gap-4"><span className="text-muted-foreground uppercase text-[10px] font-bold tracking-widest">Date:</span> <span className="border-b border-black/20 min-w-[150px]">{invoice.date}</span></div>
              <div className="flex justify-end gap-4"><span className="text-muted-foreground uppercase text-[10px] font-bold tracking-widest">Due Date:</span> <span className="border-b border-black/20 min-w-[150px]">{invoice.dueDate}</span></div>
              <div className="flex justify-end gap-4"><span className="text-muted-foreground uppercase text-[10px] font-bold tracking-widest">Tracking Number:</span> <span className="border-b border-black/20 min-w-[150px]">{invoice.shipmentId}</span></div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-8 mb-12">
          <div className="relative">
            <div className="bg-primary text-white rounded-r-full py-1 px-4 inline-flex items-center gap-2 mb-4">
              <UserCircle size={16} />
              <span className="text-xs font-bold uppercase tracking-widest">Billed To</span>
            </div>
            <div className="border-2 border-primary/20 rounded-2xl p-4 min-h-[100px] flex flex-col justify-center">
               <p className="font-bold border-b border-black/10 pb-1 mb-1">{invoice.billedTo?.name || 'Customer'}</p>
               <p className="text-sm border-b border-black/10 pb-1 mb-1">{invoice.billedTo?.location || 'Address'}</p>
               <p className="text-sm border-b border-black/10 pb-1">{invoice.billedTo?.phone || 'Contact'}</p>
            </div>
          </div>
          <div className="relative">
            <div className="bg-primary text-white rounded-r-full py-1 px-4 inline-flex items-center gap-2 mb-4">
              <UserCircle size={16} />
              <span className="text-xs font-bold uppercase tracking-widest">Shipper Information</span>
            </div>
            <div className="border-2 border-primary/20 rounded-2xl p-4 min-h-[100px] flex flex-col justify-center">
               <p className="font-bold border-b border-black/10 pb-1 mb-1">SNOC LOGISTICS AND CARGO CHINA HUB</p>
               <p className="text-sm border-b border-black/10 pb-1 mb-1">Shenzhen, Industrial Area B-402</p>
               <p className="text-sm border-b border-black/10 pb-1">+86 755 1234 5678</p>
            </div>
          </div>
        </div>

        <div className="mb-8">
           <div className="flex items-center gap-3 border-b-2 border-primary pb-2 mb-4">
              <div className="bg-white border-2 border-primary rounded-full p-1">
                <Ship size={14} className="text-primary" />
              </div>
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-primary">Shipment Details</span>
           </div>
           <div className="grid grid-cols-2 gap-x-12 gap-y-3 text-sm">
              <div className="flex justify-between border-b border-black/5 pb-1">
                <span className="font-bold text-[10px] uppercase text-muted-foreground">Origin Port:</span>
                <span className="font-medium">Shenzhen, China</span>
              </div>
              <div className="flex justify-between border-b border-black/5 pb-1">
                <span className="font-bold text-[10px] uppercase text-muted-foreground">Description of Goods:</span>
                <span className="font-medium">General Cargo</span>
              </div>
              <div className="flex justify-between border-b border-black/5 pb-1">
                <span className="font-bold text-[10px] uppercase text-muted-foreground">Destination Port:</span>
                <span className="font-medium">Tema Port, Ghana</span>
              </div>
              <div className="flex justify-between border-b border-black/5 pb-1">
                <span className="font-bold text-[10px] uppercase text-muted-foreground">Number of Packages:</span>
                <span className="font-medium">1 Lot</span>
              </div>
              <div className="flex justify-between border-b border-black/5 pb-1">
                <span className="font-bold text-[10px] uppercase text-muted-foreground">Shipment Mode:</span>
                <span className="font-medium italic">Standard</span>
              </div>
              <div className="flex justify-between border-b border-black/5 pb-1">
                <span className="font-bold text-[10px] uppercase text-muted-foreground">Total Weight:</span>
                <span className="font-medium">Calculated per Item</span>
              </div>
           </div>
        </div>

        <div className="flex-1">
          <table className="w-full border-collapse rounded-lg overflow-hidden">
            <thead className="bg-primary text-white text-[10px] uppercase tracking-widest">
              <tr>
                <th className="py-3 px-4 text-left border-r border-white/20">Description</th>
                <th className="py-3 px-4 text-center border-r border-white/20">Quantity/UOM</th>
                <th className="py-3 px-4 text-center bg-accent border-r border-white/20">Rate</th>
                <th className="py-3 px-4 text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {invoice.items?.map((item: any, i: number) => (
                <tr key={i} className="border-b border-primary/10">
                  <td className="py-3 px-4 border-r border-primary/10">{item.description}</td>
                  <td className="py-3 px-4 text-center border-r border-primary/10">{item.quantity}</td>
                  <td className="py-3 px-4 text-center border-r border-primary/10 font-bold">${item.rate?.toLocaleString()}</td>
                  <td className="py-3 px-4 text-right font-bold">${(item.quantity * item.rate).toLocaleString()}</td>
                </tr>
              ))}
              {[1,2,3].map(i => (
                <tr key={`f-${i}`} className="border-b border-primary/10 h-10">
                  <td className="border-r border-primary/10"></td>
                  <td className="border-r border-primary/10"></td>
                  <td className="border-r border-primary/10"></td>
                  <td></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex justify-end mt-8 mb-12">
          <div className="w-80">
            <div className="bg-primary text-white text-center py-1 text-[10px] font-bold uppercase tracking-widest rounded-t-lg">Totals</div>
            <div className="border-2 border-primary/20 rounded-b-lg p-4 space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span className="font-bold text-[10px] uppercase text-muted-foreground">Subtotal</span>
                <span className="border-b border-black/20 min-w-[120px] text-right">${invoice.subtotal?.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="font-bold text-[10px] uppercase text-muted-foreground">Tax (if applicable)</span>
                <span className="border-b border-black/20 min-w-[120px] text-right">$0.00</span>
              </div>
              <div className="flex justify-between items-center bg-accent text-white p-2 rounded mt-2">
                <span className="font-black italic uppercase tracking-tighter">Total Due</span>
                <span className="font-black text-xl italic">${invoice.total?.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-auto pt-8">
           <div className="flex justify-between items-end border-t-4 border-accent pt-6 pb-4">
              <div className="space-y-4 max-w-md">
                <div className="flex items-center gap-2 text-primary font-bold uppercase text-xs">
                  <DollarSign size={16} />
                  <span>Payment Instructions</span>
                </div>
                <div className="text-[10px] font-medium border-b border-black/10 pb-2">
                  {invoice.paymentInstructions}
                </div>
                <div className="flex items-center gap-2 text-primary/60 font-bold uppercase text-[10px]">
                  <MapPin size={12} />
                  <span>Reliable. Efficient. Trusted.</span>
                </div>
              </div>

              <div className="relative">
                <div className="h-32 w-32 rounded-full border-4 border-primary/10 bg-muted/20 flex items-center justify-center overflow-hidden">
                  <div className="text-[8px] font-black text-primary/20 text-center uppercase tracking-tighter leading-none">
                    GLOBAL<br/>LOGISTICS<br/>PARTNER
                  </div>
                </div>
                <div className="absolute -bottom-2 -left-2 h-8 w-8 bg-accent rounded-full border-2 border-white flex items-center justify-center text-white font-black text-[10px]">GH</div>
              </div>
           </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-4 bg-primary overflow-hidden">
          <div className="absolute top-0 left-0 h-full w-1/3 bg-accent transform skew-x-[45deg] -translate-x-1/2"></div>
        </div>
      </div>

      <style jsx global>{`
        @media print {
          .no-print { display: none !important; }
          body { background: white !important; }
          .print-p-0 { padding: 0 !important; }
          header, aside, footer { display: none !important; }
          main { padding: 0 !important; max-width: 100% !important; }
        }
      `}</style>
    </DashboardLayout>
  )
}
