
"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Ship, Search, Package, MapPin, Clock, ArrowRight, Truck, Plane, Loader2, AlertCircle, Hash, CheckCircle2, Volume2, History } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { useFirestore } from "@/firebase"
import { collection, query, where, getDocs, limit, FirestoreError } from "firebase/firestore"
import { errorEmitter } from "@/firebase/error-emitter"
import { FirestorePermissionError } from "@/firebase/errors"
import { format } from "date-fns"
import { generateShipmentVoiceUpdate } from "@/ai/flows/shipment-voice-flow"
import { useToast } from "@/hooks/use-toast"

export default function PublicTrackingPage() {
  const db = useFirestore()
  const { toast } = useToast()
  const [trackingId, setTrackingId] = useState("")
  const [searching, setSearching] = useState(false)
  const [playingVoice, setPlayingVoice] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)

  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!trackingId || !db) return
    
    setSearching(true)
    setError(null)
    setResult(null)

    const q = query(
      collection(db, "shipments"),
      where("trackingId", "==", trackingId.toUpperCase().trim()),
      limit(1)
    )

    getDocs(q)
      .then((querySnapshot) => {
        if (querySnapshot.empty) {
          setError("No shipment found with that tracking number.")
        } else {
          const doc = querySnapshot.docs[0]
          setResult({ id: doc.id, ...doc.data() })
        }
      })
      .catch(async (serverError: FirestoreError) => {
        if (serverError.code === 'permission-denied') {
          const permissionError = new FirestorePermissionError({
            path: 'shipments',
            operation: 'list',
          })
          errorEmitter.emit('permission-error', permissionError)
          setError("Access denied. Please contact support.")
        } else {
          setError("An error occurred while fetching tracking data.")
        }
      })
      .finally(() => {
        setSearching(false)
      })
  }

  const handleListenUpdate = async () => {
    if (!result) return
    setPlayingVoice(true)
    try {
      const latestMilestone = result.milestones?.[result.milestones.length - 1]
      const response = await generateShipmentVoiceUpdate({
        trackingId: result.trackingId,
        status: result.status,
        latestNote: latestMilestone?.note,
        location: latestMilestone?.location,
        method: result.method
      })

      const audio = new Audio(response.audioDataUri)
      audio.onended = () => setPlayingVoice(false)
      audio.play()
    } catch (err) {
      setPlayingVoice(false)
      toast({
        variant: "destructive",
        title: "Voice Update Failed",
        description: "Could not generate audio update at this time."
      })
    }
  }

  return (
    <div className="min-h-screen bg-muted/30 flex flex-col font-body">
      <header className="bg-primary border-b-4 border-accent p-4 text-white">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <div className="bg-white rounded-lg p-1.5 text-primary">
              <Plane size={24} className="stroke-[3px]" />
            </div>
            <div>
              <span className="font-headline font-black text-2xl italic tracking-tighter block leading-none">SNOC</span>
              <span className="text-[9px] font-bold tracking-[0.2em] uppercase block text-accent">LOGISTICS AND CARGO</span>
            </div>
          </Link>
          <div className="flex gap-2">
            <Button variant="outline" className="text-white border-white/20 hover:bg-white/10 hidden md:inline-flex" asChild>
              <Link href="/login">Portal Login</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center p-4 py-12">
        <div className="w-full max-w-2xl space-y-8">
          <div className="text-center space-y-3">
            <h1 className="text-4xl md:text-5xl font-headline font-black text-primary italic uppercase tracking-tighter">Track Your Cargo</h1>
            <p className="text-muted-foreground font-medium uppercase tracking-widest text-xs">
              Reliable • Efficient • Trusted • Connecting China to Ghana
            </p>
          </div>

          <Card className="border-none shadow-2xl overflow-hidden bg-white">
            <CardContent className="pt-6">
              <form onSubmit={handleTrack} className="flex flex-col md:flex-row gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-4 top-3.5 h-5 w-5 text-muted-foreground" />
                  <Input 
                    placeholder="ENTER TRACKING # (e.g. GL-1234)" 
                    className="pl-12 h-14 text-lg bg-muted/30 border-2 border-transparent focus-visible:border-primary font-bold placeholder:font-normal"
                    value={trackingId}
                    onChange={(e) => setTrackingId(e.target.value)}
                  />
                </div>
                <Button type="submit" size="lg" disabled={searching} className="bg-accent text-white hover:bg-accent/90 px-10 h-14 font-black uppercase italic tracking-wider">
                  {searching ? <Loader2 className="animate-spin" /> : "Track Now"}
                </Button>
              </form>
            </CardContent>
          </Card>

          {error && (
            <div className="flex items-center gap-2 p-4 rounded-lg bg-destructive/10 text-destructive text-sm font-semibold animate-in fade-in slide-in-from-top-2">
              <AlertCircle size={18} />
              {error}
            </div>
          )}

          {result && (
            <div className="space-y-6">
              <Card className="border-none shadow-xl animate-in fade-in slide-in-from-bottom-4 duration-500 bg-white">
                <CardHeader className="bg-primary text-primary-foreground rounded-t-lg border-b-4 border-accent">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-2xl font-black italic tracking-tighter">{result.trackingId}</CardTitle>
                      <CardDescription className="text-primary-foreground/70 font-bold uppercase text-[10px] tracking-widest mt-1">Status: Active Consignment</CardDescription>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <Badge className="bg-accent text-white font-black px-4 py-1 italic uppercase tracking-wide border-none">{result.status}</Badge>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="text-white hover:bg-white/10 h-8 font-bold uppercase text-[9px] tracking-widest"
                        onClick={handleListenUpdate}
                        disabled={playingVoice}
                      >
                        {playingVoice ? <Loader2 className="mr-2 h-3 w-3 animate-spin" /> : <Volume2 className="mr-2 h-3 w-3" />}
                        {playingVoice ? "Generating Audio..." : "Listen to Update"}
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-8 space-y-10">
                  <div className="flex items-center justify-between relative px-4">
                    <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-1 bg-muted/50 z-0 mx-8"></div>
                    <div className="relative z-10 bg-white p-3 rounded-full border-4 border-primary shadow-md">
                      <MapPin className="h-6 w-6 text-primary" />
                      <p className="absolute -bottom-7 left-1/2 -translate-x-1/2 text-[10px] font-black uppercase whitespace-nowrap tracking-widest text-primary">China</p>
                    </div>
                    <div className={`relative z-10 bg-white p-3 rounded-full border-4 shadow-md ${result.status === 'Delivered' ? 'border-primary' : 'border-accent animate-pulse'}`}>
                      {result.method === 'Air' ? <Plane className="h-6 w-6 text-accent" /> : <Ship className="h-6 w-6 text-accent" />}
                    </div>
                    <div className={`relative z-10 bg-white p-3 rounded-full border-4 shadow-md ${result.status === 'Delivered' ? 'border-primary' : 'border-muted/50'}`}>
                      <MapPin className={`h-6 w-6 ${result.status === 'Delivered' ? 'text-primary' : 'text-muted-foreground'}`} />
                      <p className={`absolute -bottom-7 left-1/2 -translate-x-1/2 text-[10px] font-black uppercase whitespace-nowrap tracking-widest ${result.status === 'Delivered' ? 'text-primary' : 'text-muted-foreground'}`}>Ghana</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-12 pt-6">
                    <div className="space-y-2">
                      <p className="text-[10px] text-muted-foreground uppercase font-black tracking-[0.2em]">Latest Update</p>
                      <p className="font-bold text-primary flex items-center gap-2">
                        <Clock size={18} className="text-accent" />
                        {result.status === "Warehouse" ? "Consignment received at China Hub" : 
                         result.status === "In Transit" ? "Cargo in transit to destination" : 
                         result.status === "Customs" ? "Arrived at destination port, clearing customs" : 
                         "Delivered to consignee"}
                      </p>
                      {result.containerNumber && (
                        <p className="text-xs text-primary font-bold flex items-center gap-1 mt-2">
                          <Hash size={12} className="text-accent" /> Container: {result.containerNumber}
                        </p>
                      )}
                    </div>
                    <div className="space-y-2 text-right">
                      <p className="text-[10px] text-muted-foreground uppercase font-black tracking-[0.2em]">Route Info</p>
                      <p className="font-black text-primary text-xl italic uppercase tracking-tighter">
                        {result.origin?.split(' ')[0]} <ArrowRight className="inline mx-1 text-accent" /> GH
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Enhanced Public Timeline */}
              <Card className="border-none shadow-xl bg-white overflow-hidden">
                <CardHeader className="bg-muted/30 border-b">
                  <CardTitle className="text-xs uppercase font-black text-primary tracking-[0.2em] flex items-center gap-2">
                    <History size={14} className="text-accent" />
                    Tracking History
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-8">
                  <div className="relative space-y-8 before:absolute before:inset-0 before:ml-4 before:-translate-x-px before:h-full before:w-0.5 before:bg-muted">
                    {result.milestones && result.milestones.length > 0 ? (
                      [...result.milestones].reverse().map((m: any, i: number) => (
                        <div key={i} className="relative flex items-start group">
                          <div className={`absolute left-0 w-8 h-8 -ml-4 flex items-center justify-center rounded-full border-4 border-white ${i === 0 ? 'bg-accent shadow-[0_0_10px_rgba(225,29,72,0.4)]' : 'bg-primary'} text-white shrink-0 z-10 transition-all`}>
                            <CheckCircle2 size={12} />
                          </div>
                          <div className="pl-8 w-full">
                            <div className="flex items-center justify-between mb-1">
                              <span className={`text-sm font-black italic uppercase tracking-tight ${i === 0 ? 'text-accent' : 'text-primary'}`}>{m.status}</span>
                              <time className="text-[9px] font-bold text-muted-foreground uppercase">{m.timestamp ? format(new Date(m.timestamp), 'MMM d, yyyy HH:mm') : 'N/A'}</time>
                            </div>
                            <p className="text-xs text-muted-foreground font-medium leading-relaxed italic">
                               {m.location && <span className="font-bold text-primary not-italic mr-1">@{m.location}:</span>}
                               {m.note}
                            </p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="pl-8">
                        <p className="text-xs text-muted-foreground font-bold uppercase italic">Tracking initialized. Pending hub updates.</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          <div className="text-center pt-4">
            <p className="text-sm font-medium text-muted-foreground">
              Questions about your SNOC shipment? <Link href="#" className="text-accent font-bold hover:underline underline-offset-4">Contact Support</Link>
            </p>
          </div>
        </div>
      </main>

      <footer className="p-8 text-center bg-white border-t border-muted">
        <p className="text-[10px] text-muted-foreground font-black uppercase tracking-[0.3em] mb-2">
          Reliable • Efficient • Trusted
        </p>
        <p className="text-[9px] text-muted-foreground/60 uppercase font-bold">
          © 2024 SNOC LOGISTICS AND CARGO SOLUTIONS LIMITED. All rights reserved.
        </p>
      </footer>
    </div>
  )
}
