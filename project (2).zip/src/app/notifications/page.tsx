
"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Bell, Mail, Ship, Check, Clock, CheckCircle2, AlertCircle, Send, Users, Megaphone, Loader2, Key, Smartphone } from "lucide-react"
import { useState, useEffect, useMemo } from "react"
import { useSearchParams } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { useUser, useFirestore, useCollection, useMemoFirebase } from "@/firebase"
import { collection, query, where, limit } from "firebase/firestore"

const initialNotifications = [
  { id: 1, title: "Shipment Arrived", desc: "Cargo GL-1005 has arrived at Tema Port terminal 3 and is awaiting clearance.", time: "2 hours ago", type: "success", read: false },
  { id: 2, title: "Customs Hold", desc: "GL-3422 requires additional documentation (Certificate of Origin) for clearance.", time: "5 hours ago", type: "warning", read: false },
  { id: 3, title: "Automated Dispatch", desc: "Credentials successfully sent to consignee via Email/SMS following payment confirmation.", time: "Just now", type: "info", read: false },
]

export default function NotificationsPage() {
  const { user } = useUser()
  const db = useFirestore()
  const searchParams = useSearchParams()
  const { toast } = useToast()
  
  const [notifications, setNotifications] = useState(initialNotifications)
  const [activeId, setActiveId] = useState<number | null>(null)
  const [sendingBulk, setSendingBulk] = useState(false)

  const [effectiveEmail, setEffectiveEmail] = useState<string | null>(null)
  useEffect(() => {
    setEffectiveEmail(user?.email || (typeof window !== 'undefined' ? sessionStorage.getItem("ghaLink_guest_email") : null))
  }, [user])

  const clientsRef = useMemoFirebase(() => db ? collection(db, 'clients') : null, [db])
  const clientMatchQuery = useMemoFirebase(() => {
    if (!clientsRef || !effectiveEmail) return null
    return query(clientsRef, where('email', '==', effectiveEmail), limit(1))
  }, [clientsRef, effectiveEmail])
  
  const { data: clientRecord } = useCollection(clientMatchQuery)
  const isClient = !!(clientRecord && clientRecord.length > 0) || effectiveEmail === "demo@client.com"

  useEffect(() => {
    const id = searchParams.get("id")
    if (id) {
      const numericId = parseInt(id)
      setActiveId(numericId)
      markAsRead(numericId)
    }
  }, [searchParams])

  const markAsRead = (id: number) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    )
  }

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })))
    toast({ title: "All Marked as Read" })
  }

  const handleSendBulkUpdate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setSendingBulk(true)
    const formData = new FormData(e.currentTarget)
    
    setTimeout(() => {
      setSendingBulk(false)
      toast({
        title: "Bulk Dispatch Successful",
        description: `Notification sent to all active shippers.`,
      })
      e.currentTarget.reset()
      
      const newNotif = {
        id: Date.now(),
        title: formData.get('subject') as string,
        desc: formData.get('message') as string,
        time: "Just now",
        type: "info",
        read: false
      }
      setNotifications(prev => [newNotif, ...prev])
    }, 1500)
  }

  const activeNotification = notifications.find(n => n.id === activeId)

  return (
    <DashboardLayout>
      <div className="max-w-5xl mx-auto space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b pb-6">
          <div>
            <h2 className="text-4xl font-headline font-black text-primary italic uppercase tracking-tighter">Communication Hub</h2>
            <p className="text-muted-foreground mt-1 uppercase text-[10px] font-bold tracking-widest">Reliable • Efficient • Trusted Messaging</p>
          </div>
          <Button variant="outline" size="sm" onClick={markAllAsRead} className="font-bold uppercase text-[10px] tracking-widest border-primary/20">
            <CheckCircle2 className="mr-2 h-4 w-4" /> Mark all as read
          </Button>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-4">
            {activeNotification && (
              <Card className="border-none bg-accent/5 border-l-4 border-accent animate-in fade-in slide-in-from-top-4 duration-500 shadow-lg">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl font-black italic text-primary uppercase tracking-tight">{activeNotification.title}</CardTitle>
                    <Badge className="bg-accent text-white italic uppercase tracking-widest font-black">Focused Update</Badge>
                  </div>
                  <CardDescription className="text-xs font-bold uppercase text-muted-foreground">{activeNotification.time}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-lg text-primary font-medium leading-relaxed italic border-l-2 border-primary/20 pl-4">
                    "{activeNotification.desc}"
                  </p>
                  <div className="flex gap-2">
                    <Button size="sm" className="bg-primary font-bold uppercase text-[10px]">Open Shipment Record</Button>
                    <Button size="sm" variant="ghost" onClick={() => setActiveId(null)} className="font-bold uppercase text-[10px]">Dismiss Detail</Button>
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="space-y-4">
              <h3 className="text-xs font-black uppercase tracking-widest text-primary flex items-center gap-2">
                <Bell size={14} className="text-accent" />
                Latest Alerts
              </h3>
              {notifications.map((n) => (
                <Card 
                  key={n.id} 
                  className={`border-none shadow-sm transition-all hover:translate-x-1 cursor-pointer ${n.read ? 'opacity-80' : 'bg-white border-l-4 border-primary shadow-md'} ${activeId === n.id ? 'ring-2 ring-accent' : ''}`}
                  onClick={() => {
                    setActiveId(n.id)
                    markAsRead(n.id)
                  }}
                >
                  <CardContent className="p-4 flex gap-4">
                    <div className={`h-12 w-12 rounded-full flex items-center justify-center shrink-0 border-2 ${
                      n.type === 'success' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 
                      n.type === 'warning' ? 'bg-orange-50 text-orange-600 border-orange-100' : 
                      'bg-primary/5 text-primary border-primary/10'
                    }`}>
                      {n.type === 'success' ? <Ship size={24} /> : n.type === 'warning' ? <AlertCircle size={24} /> : (n.title.includes('Credentials') ? <Key size={24}/> : <Bell size={24} />)}
                    </div>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between">
                        <p className={`text-sm font-black italic uppercase tracking-tight ${!n.read ? 'text-primary' : 'text-muted-foreground'}`}>{n.title}</p>
                        <p className="text-[9px] font-bold text-muted-foreground uppercase tracking-widest">{n.time}</p>
                      </div>
                      <p className="text-xs text-muted-foreground font-medium leading-tight">{n.desc}</p>
                    </div>
                    {!n.read && (
                      <div className="h-3 w-3 rounded-full bg-accent mt-2 animate-pulse shadow-[0_0_10px_rgba(225,29,72,0.5)]"></div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {!isClient && (
            <div className="space-y-6">
              <Card className="border-none shadow-xl bg-primary text-white overflow-hidden">
                <CardHeader className="bg-accent/10 border-b border-white/10">
                  <CardTitle className="flex items-center gap-2 italic uppercase tracking-tighter">
                    <Megaphone className="h-5 w-5 text-accent" />
                    Bulk Dispatch
                  </CardTitle>
                  <CardDescription className="text-white/60 text-[10px] uppercase font-bold tracking-widest">Update all active consignees instantly.</CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <form onSubmit={handleSendBulkUpdate} className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-[10px] font-bold uppercase tracking-widest opacity-70">Broadcast Channel</Label>
                      <div className="flex gap-2">
                        <Badge className="bg-white/10 text-white border-white/20">Email</Badge>
                        <Badge className="bg-white/10 text-white border-white/20">SMS</Badge>
                        <Badge className="bg-accent text-white">In-App</Badge>
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="subject" className="text-[10px] font-bold uppercase opacity-70">Subject Header</Label>
                      <Input id="subject" name="subject" placeholder="e.g. Vessel GH-402 Delay" className="bg-white/5 border-white/10 text-white placeholder:text-white/20 h-10" required />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="message" className="text-[10px] font-bold uppercase opacity-70">Message Body</Label>
                      <Textarea id="message" name="message" placeholder="Type broadcast message..." className="bg-white/5 border-white/10 text-white placeholder:text-white/20 min-h-[100px]" required />
                    </div>
                    <Button type="submit" disabled={sendingBulk} className="w-full bg-accent hover:bg-accent/90 text-white font-black italic uppercase tracking-wider h-12">
                      {sendingBulk ? <Loader2 className="animate-spin mr-2 h-4 w-4" /> : <Send className="mr-2 h-4 w-4" />}
                      Dispatch to Active Shippers
                    </Button>
                  </form>
                </CardContent>
              </Card>

              <Card className="border-none shadow-sm bg-muted/20">
                <CardHeader>
                  <CardTitle className="text-[10px] uppercase font-black text-primary tracking-[0.2em]">Live Channels</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-lg bg-white border shadow-sm">
                    <div className="flex items-center gap-2">
                       <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                       <span className="text-[10px] font-bold uppercase text-primary">Email Service</span>
                    </div>
                    <span className="text-[9px] font-black italic text-emerald-600">CONNECTED</span>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg bg-white border shadow-sm">
                    <div className="flex items-center gap-2">
                       <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                       <span className="text-[10px] font-bold uppercase text-primary">SMS Gateway</span>
                    </div>
                    <span className="text-[9px] font-black italic text-emerald-600">CONNECTED</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {isClient && (
            <div className="space-y-6">
              <Card className="border-none bg-primary text-white shadow-lg overflow-hidden relative">
                <div className="absolute top-0 right-0 p-4 opacity-10">
                   <Users size={80} />
                </div>
                <CardHeader>
                  <CardTitle className="text-lg italic uppercase tracking-tighter">Support Access</CardTitle>
                  <CardDescription className="text-white/60 text-[10px] uppercase font-bold">Dedicated assistance for your cargo.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 relative z-10">
                  <p className="text-xs leading-relaxed opacity-80">
                    Need direct clarification on an update? Our China-Ghana support team is available 24/7 for Snoc Business Partners.
                  </p>
                  <Button className="w-full bg-accent text-white font-black uppercase italic tracking-wider h-12 shadow-xl">
                    Open Live Support
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  )
}
