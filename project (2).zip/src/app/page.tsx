
"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Ship, Package, TrendingUp, Users, ArrowUpRight, Plane, Plus, Loader2, Truck, Search, History, MapPin, Fingerprint, UserCheck, Megaphone } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { useCollection, useFirestore, useMemoFirebase, useUser } from "@/firebase"
import { collection, query, orderBy, limit, where } from "firebase/firestore"
import { useMemo, useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  Legend
} from "recharts"
import { format, subMonths } from "date-fns"

export default function Dashboard() {
  const db = useFirestore()
  const { user } = useUser()
  const router = useRouter()
  
  // Get effective email for role detection
  const [effectiveEmail, setEffectiveEmail] = useState<string | null>(null)
  useEffect(() => {
    setEffectiveEmail(user?.email || (typeof window !== 'undefined' ? sessionStorage.getItem("ghaLink_guest_email") : null))
  }, [user])

  // Identify Role
  const clientsRef = useMemoFirebase(() => db ? collection(db, 'clients') : null, [db])
  const clientMatchQuery = useMemoFirebase(() => {
    if (!clientsRef || !effectiveEmail) return null
    return query(clientsRef, where('email', '==', effectiveEmail), limit(1))
  }, [clientsRef, effectiveEmail])
  
  const { data: clientRecord, loading: loadingIdentity } = useCollection(clientMatchQuery)
  
  // Memoize clientData to prevent re-render loops from object literals
  const clientData = useMemo(() => {
    if (clientRecord && clientRecord.length > 0) return clientRecord[0]
    if (effectiveEmail === "demo@client.com") return { name: "Demo Client", id: "demo-uid" }
    return null
  }, [clientRecord, effectiveEmail])

  const isClient = !!clientData

  // Data Fetching
  const allShipmentsRef = useMemoFirebase(() => db ? collection(db, 'shipments') : null, [db])
  const { data: allShipments } = useCollection(!isClient ? allShipmentsRef : null)
  const { data: allClients } = useCollection(!isClient ? clientsRef : null)

  const recentAdminShipmentsQuery = useMemoFirebase(() => {
    if (!allShipmentsRef || isClient) return null
    return query(allShipmentsRef, orderBy('createdAt', 'desc'), limit(5))
  }, [allShipmentsRef, isClient])
  const { data: recentAdminShipments } = useCollection(recentAdminShipmentsQuery)

  const myShipmentsQuery = useMemoFirebase(() => {
    if (!allShipmentsRef || !isClient || !clientData?.id) return null
    return query(allShipmentsRef, where('clientId', '==', clientData.id))
  }, [allShipmentsRef, isClient, clientData?.id])
  const { data: myShipments } = useCollection(myShipmentsQuery)

  // Role-Specific Statistics
  const stats = useMemo(() => {
    const dataSet = isClient ? myShipments : allShipments
    const weightTotal = dataSet?.reduce((acc, s) => acc + (s.weight || 0), 0) || 0
    const valueTotal = dataSet?.reduce((acc, s) => acc + (s.declaredValue || 0), 0) || 0
    
    if (isClient) {
      return [
        { name: "My Active Cargo", value: (myShipments?.length || 0).toString(), icon: Ship, color: "text-primary", bg: "bg-primary/10", trend: "Live Tracking" },
        { name: "Total Weight", value: `${weightTotal.toLocaleString()} kg`, icon: Package, color: "text-accent", bg: "bg-accent/10", trend: "Volume Handled" },
        { name: "Account Status", value: "Verified", icon: UserCheck, color: "text-primary", bg: "bg-primary/10", trend: "Active Hub" },
        { name: "Declared Value", value: `$${valueTotal.toLocaleString()}`, icon: TrendingUp, color: "text-accent", bg: "bg-accent/10", trend: "Verified" },
      ]
    }
    return [
      { name: "Global Active Cargo", value: (allShipments?.length || 0).toString(), icon: Ship, color: "text-primary", bg: "bg-primary/10", trend: "+12% Growth" },
      { name: "Global Weight", value: `${weightTotal.toLocaleString()} kg`, icon: Package, color: "text-accent", bg: "bg-accent/10", trend: "+5% Volume" },
      { name: "Unique Clients", value: (allClients?.length || 0).toString(), icon: Users, color: "text-primary", bg: "bg-primary/10", trend: "Active Registry" },
      { name: "Revenue Value", value: `$${valueTotal.toLocaleString()}`, icon: TrendingUp, color: "text-accent", bg: "bg-accent/10", trend: "+18% Profit" },
    ]
  }, [allShipments, allClients, myShipments, isClient])

  // Chart Logic
  const chartData = useMemo(() => {
    const dataSet = isClient ? myShipments : allShipments
    if (!dataSet) return []

    const months = Array.from({ length: 6 }).map((_, i) => {
      const d = subMonths(new Date(), 5 - i)
      return {
        name: format(d, 'MMM'),
        volume: 0
      }
    })

    dataSet.forEach(s => {
      const sDate = s.createdAt?.toDate ? s.createdAt.toDate() : new Date(s.date || Date.now())
      const sMonth = format(sDate, 'MMM')
      const target = months.find(m => m.name === sMonth)
      if (target) {
        target.volume += (s.weight || 0)
      }
    })

    return months
  }, [allShipments, myShipments, isClient])

  const pieData = useMemo(() => {
    const dataSet = isClient ? myShipments : allShipments
    if (!dataSet) return []
    
    const air = dataSet.filter(s => s.method === 'Air').length
    const sea = dataSet.filter(s => s.method === 'Sea').length
    const total = air + sea || 1

    return [
      { name: 'Air Freight', value: Math.round((air / total) * 100), color: '#1a365d' },
      { name: 'Sea Freight', value: Math.round((sea / total) * 100), color: '#e11d48' },
    ]
  }, [allShipments, myShipments, isClient])

  if (loadingIdentity) {
    return <DashboardLayout><div className="flex justify-center p-20"><Loader2 className="animate-spin h-8 w-8 text-primary" /></div></DashboardLayout>
  }

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b pb-6">
          <div className="space-y-1">
            <h2 className="text-4xl font-headline font-black tracking-tighter italic text-primary uppercase">
              {isClient ? `Client Hub: ${clientData?.name?.split(' ')[0]}` : "Operational Control Center"}
            </h2>
            <div className="flex items-center gap-2">
               <p className="text-muted-foreground font-bold uppercase tracking-widest text-[10px]">
                 Reliable • Efficient • Trusted • China-Ghana Logistics
               </p>
               {isClient && clientData?.id && (
                 <Badge variant="outline" className="text-[10px] font-black italic border-primary/20 text-primary uppercase">
                   ID: SN-{clientData.id.substring(0, 4).toUpperCase()}
                 </Badge>
               )}
            </div>
          </div>
          <div className="flex gap-2">
            {!isClient ? (
              <>
                <Button asChild variant="outline" className="h-12 font-bold uppercase italic tracking-wider border-primary/20">
                  <Link href="/notifications">
                    <Megaphone className="mr-2 h-4 w-4" /> Broadcast Update
                  </Link>
                </Button>
                <Button asChild className="bg-primary hover:bg-primary/90 shadow-lg h-12 font-bold uppercase italic tracking-wider">
                  <Link href="/shipments/new">
                    <Plus className="mr-2 h-4 w-4" /> New Consignment
                  </Link>
                </Button>
              </>
            ) : (
              <>
                <Button asChild variant="outline" className="h-12 font-bold uppercase italic tracking-wider border-primary/20">
                  <Link href="/track">
                    <Search className="mr-2 h-4 w-4" /> Track Item
                  </Link>
                </Button>
                <Button asChild className="bg-primary hover:bg-primary/90 shadow-lg h-12 font-bold uppercase italic tracking-wider">
                  <Link href="/calculator">
                    <TrendingUp className="mr-2 h-4 w-4" /> Cost Calculator
                  </Link>
                </Button>
              </>
            )}
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <Card key={stat.name} className="border-none shadow-sm hover:shadow-md transition-shadow group">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className={`p-3 rounded-xl ${stat.bg} ${stat.color} group-hover:scale-110 transition-transform`}>
                    <stat.icon size={24} />
                  </div>
                  <div className="flex items-center text-[10px] font-black uppercase tracking-tighter text-emerald-600">
                    {stat.trend} <ArrowUpRight className="ml-1 h-3 w-3" />
                  </div>
                </div>
                <div className="mt-4">
                  <p className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">{stat.name}</p>
                  <p className="text-2xl font-black italic tracking-tight">{stat.value}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Analytics Section */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
          <Card className="lg:col-span-4 border-none shadow-sm">
            <CardHeader>
              <CardTitle className="text-primary italic uppercase tracking-tighter">
                {isClient ? "My Cargo Volume (kg)" : "System Volume Trends (kg)"}
              </CardTitle>
              <CardDescription className="text-[10px] uppercase font-bold tracking-widest">Cargo activity across the last 6 operational months.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                {chartData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(0,0,0,0.05)" />
                      <XAxis dataKey="name" fontSize={10} axisLine={false} tickLine={false} />
                      <YAxis fontSize={10} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}kg`} />
                      <Tooltip 
                        cursor={{fill: 'rgba(26,54,93,0.05)'}} 
                        contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                      />
                      <Bar dataKey="volume" fill="#1a365d" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center text-muted-foreground uppercase text-[10px] font-bold">No historical data available</div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="lg:col-span-3 border-none shadow-sm">
            <CardHeader>
              <CardTitle className="text-primary italic uppercase tracking-tighter">Freight Distribution</CardTitle>
              <CardDescription className="text-[10px] uppercase font-bold">Method split of your logistics history.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={pieData} cx="50%" cy="50%" innerRadius={60} outerRadius={80} dataKey="value" paddingAngle={5}>
                      {pieData.map((entry, idx) => <Cell key={idx} fill={entry.color} strokeWidth={0} />)}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Bottom Activity Section */}
        <Card className="border-none shadow-sm overflow-hidden">
          <CardHeader className="bg-primary text-white border-b-4 border-accent">
            <CardTitle className="italic uppercase tracking-tighter">
              {isClient ? "My Active Traffic" : "Global Terminal Activity"}
            </CardTitle>
            <CardDescription className="text-white/60 text-[10px] uppercase font-bold">
              {isClient ? "Real-time status of your shipments." : "Global status updates across the Snoc network."}
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            {(isClient ? myShipments : recentAdminShipments) && (isClient ? myShipments!.length > 0 : recentAdminShipments!.length > 0) ? (
              <div className="divide-y">
                {(isClient ? myShipments : recentAdminShipments)!.map((s) => (
                  <div key={s.id} className="flex items-center justify-between p-4 hover:bg-muted/30 transition-colors cursor-pointer" onClick={() => router.push(`/shipments/${s.id}`)}>
                    <div className="flex items-center gap-4">
                      <div className="bg-primary/5 p-2 rounded-full text-primary">
                        {s.method === 'Air' ? <Plane size={18} /> : <Ship size={18} />}
                      </div>
                      <div>
                        <p className="font-black italic text-primary uppercase text-sm">{s.trackingId}</p>
                        <p className="text-[10px] font-bold text-muted-foreground uppercase">
                          {isClient ? `${s.origin} → ${s.destination}` : s.clientName}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                       <div className="text-right hidden md:block">
                          <p className="text-[10px] font-bold text-muted-foreground uppercase">Weight</p>
                          <p className="text-xs font-black italic">{s.weight} kg</p>
                       </div>
                       <Badge className={
                        s.status === "Delivered" ? "bg-emerald-100 text-emerald-700" :
                        s.status === "In Transit" ? "bg-primary text-white" :
                        "bg-accent text-white"
                      }>
                        {s.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-12 text-center text-muted-foreground uppercase font-bold text-[10px] tracking-widest">
                <Truck className="h-12 w-12 mx-auto mb-4 opacity-10" />
                No active traffic identified for your account.
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
