
"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from "@/components/ui/table"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Search, Plus, Mail, Phone, Loader2, Trash2, Edit, MapPin, UserCheck, Eye, Fingerprint, Key } from "lucide-react"
import { useState } from "react"
import { useCollection, useFirestore, useMemoFirebase } from "@/firebase"
import { collection, addDoc, deleteDoc, doc, updateDoc } from "firebase/firestore"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { errorEmitter } from "@/firebase/error-emitter"
import { FirestorePermissionError } from "@/firebase/errors"
import { useRouter } from "next/navigation"
import { Badge } from "@/components/ui/badge"

export default function ClientsPage() {
  const db = useFirestore()
  const router = useRouter()
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [isAddOpen, setIsAddOpen] = useState(false)
  const [editingClient, setEditingClient] = useState<any>(null)
  
  const clientsRef = useMemoFirebase(() => db ? collection(db, 'clients') : null, [db])
  const { data: clients, loading } = useCollection(clientsRef)

  const filteredClients = (clients || []).filter(c => 
    c.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.id?.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const handleAddClient = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!db) return
    const formData = new FormData(e.currentTarget)
    const newClient = {
      name: formData.get('name') as string,
      email: (formData.get('email') as string).toLowerCase().trim(),
      phone: formData.get('phone') as string,
      location: formData.get('location') as string,
      accessCode: formData.get('accessCode') as string || Math.floor(1000 + Math.random() * 9000).toString(),
      totalShipments: 0,
      createdAt: new Date().toISOString()
    }

    addDoc(collection(db, 'clients'), newClient)
      .then(() => {
        setIsAddOpen(false)
        toast({ title: "Client Registered", description: `${newClient.name} is now in the Snoc database.` })
      })
      .catch(async (err) => {
        const permissionError = new FirestorePermissionError({
          path: 'clients',
          operation: 'create',
          requestResourceData: newClient,
        })
        errorEmitter.emit('permission-error', permissionError)
      })
  }

  const handleEditClient = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!db || !editingClient) return
    const formData = new FormData(e.currentTarget)
    const updated = {
      name: formData.get('name') as string,
      email: (formData.get('email') as string).toLowerCase().trim(),
      phone: formData.get('phone') as string,
      location: formData.get('location') as string,
      accessCode: formData.get('accessCode') as string,
    }

    updateDoc(doc(db, 'clients', editingClient.id), updated)
      .then(() => {
        setEditingClient(null)
        toast({ title: "Client Updated" })
      })
      .catch(async (err) => {
        const permissionError = new FirestorePermissionError({
          path: `clients/${editingClient.id}`,
          operation: 'update',
          requestResourceData: updated,
        })
        errorEmitter.emit('permission-error', permissionError)
      })
  }

  const handleDelete = (id: string) => {
    if (!db || !confirm("Are you sure you want to remove this client record? This will not delete their shipments.")) return
    
    deleteDoc(doc(db, 'clients', id))
      .then(() => {
        toast({ title: "Client Removed" })
      })
      .catch(async (err) => {
        const permissionError = new FirestorePermissionError({
          path: `clients/${id}`,
          operation: 'delete',
        })
        errorEmitter.emit('permission-error', permissionError)
      })
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-3xl font-headline font-bold text-primary italic uppercase tracking-tighter">Client Registry</h2>
            <p className="text-muted-foreground mt-1 uppercase text-[10px] font-bold tracking-widest">Reliable • Efficient • Trusted Customer Database</p>
          </div>
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90 font-bold italic uppercase tracking-wider">
                <Plus className="mr-2 h-4 w-4" /> Register New Client
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <form onSubmit={handleAddClient}>
                <DialogHeader>
                  <DialogTitle className="text-primary italic uppercase tracking-tighter">New Customer Entry</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="name" className="text-[10px] uppercase font-bold text-muted-foreground">Full Name / Company</Label>
                    <Input id="name" name="name" placeholder="e.g. John Doe / Tech Solutions" required />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="email" className="text-[10px] uppercase font-bold text-muted-foreground">Email Address</Label>
                    <Input id="email" name="email" type="email" placeholder="customer@email.com" required />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="phone" className="text-[10px] uppercase font-bold text-muted-foreground">Phone Number</Label>
                    <Input id="phone" name="phone" placeholder="+233..." required />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="location" className="text-[10px] uppercase font-bold text-muted-foreground">Primary Location (Ghana)</Label>
                    <Input id="location" name="location" placeholder="e.g. Accra, Kumasi" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="accessCode" className="text-[10px] uppercase font-bold text-muted-foreground">Tracking Passcode (Temp Login)</Label>
                    <Input id="accessCode" name="accessCode" placeholder="Auto-generated if empty" />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit" className="bg-accent text-white font-bold uppercase italic tracking-wider">Save Client Record</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card className="border-none shadow-sm overflow-hidden">
          <CardHeader className="p-4 md:p-6 pb-0 border-b bg-muted/20">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="relative w-full md:w-96">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Search by name, email or Client ID..." 
                  className="pl-9 bg-white border-primary/10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
                Total Records: {filteredClients.length}
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {loading ? (
              <div className="flex justify-center p-12"><Loader2 className="animate-spin text-primary h-8 w-8" /></div>
            ) : (
              <Table>
                <TableHeader className="bg-muted/30">
                  <TableRow>
                    <TableHead className="font-bold uppercase text-[10px]">Customer Information</TableHead>
                    <TableHead className="font-bold uppercase text-[10px]">Tracking Access</TableHead>
                    <TableHead className="font-bold uppercase text-[10px]">Region/Location</TableHead>
                    <TableHead className="font-bold uppercase text-[10px]">Contact Channels</TableHead>
                    <TableHead className="text-center font-bold uppercase text-[10px]">Shipment Vol.</TableHead>
                    <TableHead className="text-right font-bold uppercase text-[10px]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredClients.map((client) => (
                    <TableRow key={client.id} className="hover:bg-primary/5 transition-colors group">
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-10 w-10 border-2 border-primary/10 shadow-sm">
                            <AvatarFallback className="bg-primary text-white text-xs font-black italic">
                              {client.name?.substring(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-black text-primary text-sm uppercase tracking-tight italic">{client.name}</p>
                            <p className="text-[9px] font-bold text-muted-foreground uppercase tracking-widest">SN-{client.id.substring(0, 4).toUpperCase()}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                         <div className="space-y-1">
                            <div className="flex items-center gap-1.5">
                               <Key size={10} className="text-accent" />
                               <span className="text-xs font-black italic text-primary">{client.accessCode || 'No Code'}</span>
                            </div>
                            <p className="text-[8px] uppercase font-bold text-muted-foreground">Portal Passcode</p>
                         </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5 text-xs font-medium text-primary/70">
                          <MapPin size={12} className="text-accent" />
                          {client.location || 'Not Specified'}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5 text-[11px] font-bold text-muted-foreground">
                            <Phone className="h-3 w-3" /> {client.phone}
                          </div>
                          <div className="flex items-center gap-1.5 text-[11px] font-bold text-muted-foreground">
                            <Mail className="h-3 w-3" /> {client.email}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="inline-flex flex-col items-center justify-center">
                          <span className="text-lg font-black italic text-primary">{client.totalShipments || 0}</span>
                          <span className="text-[8px] uppercase font-bold text-muted-foreground tracking-tighter">Cargo Items</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button variant="ghost" size="icon" className="hover:bg-primary/10 hover:text-primary" onClick={() => router.push(`/clients/${client.id}`)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="hover:bg-primary/10 hover:text-primary" onClick={() => setEditingClient(client)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="text-destructive hover:bg-destructive/10" onClick={() => handleDelete(client.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
            {!loading && filteredClients.length === 0 && (
              <div className="p-20 text-center">
                <UserCheck className="h-12 w-12 text-muted-foreground/20 mx-auto mb-4" />
                <p className="text-muted-foreground font-bold uppercase text-[10px] tracking-[0.2em]">No matching client records found in the Snoc database.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Edit Dialog */}
        <Dialog open={!!editingClient} onOpenChange={(open) => !open && setEditingClient(null)}>
          <DialogContent>
            {editingClient && (
              <form onSubmit={handleEditClient}>
                <DialogHeader>
                  <DialogTitle className="text-primary italic uppercase tracking-tighter">Modify Client Record</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="edit-name" className="text-[10px] uppercase font-bold text-muted-foreground">Full Name</Label>
                    <Input id="edit-name" name="name" defaultValue={editingClient.name} required />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="edit-email" className="text-[10px] uppercase font-bold text-muted-foreground">Email</Label>
                    <Input id="edit-email" name="email" type="email" defaultValue={editingClient.email} required />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="edit-phone" className="text-[10px] uppercase font-bold text-muted-foreground">Phone</Label>
                    <Input id="edit-phone" name="phone" defaultValue={editingClient.phone} required />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="edit-location" className="text-[10px] uppercase font-bold text-muted-foreground">Location</Label>
                    <Input id="edit-location" name="location" defaultValue={editingClient.location} />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="edit-code" className="text-[10px] uppercase font-bold text-muted-foreground">Tracking Passcode</Label>
                    <Input id="edit-code" name="accessCode" defaultValue={editingClient.accessCode} required />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit" className="bg-primary text-white font-bold uppercase italic tracking-wider">Update Record</Button>
                </DialogFooter>
              </form>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}
