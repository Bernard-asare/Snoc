
"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from "@/components/ui/table"
import { useDoc, useCollection, useFirestore, useMemoFirebase } from "@/firebase"
import { doc, collection, query, where } from "firebase/firestore"
import { useParams, useRouter } from "next/navigation"
import { ArrowLeft, User, Phone, Mail, MapPin, Ship, Package, Calendar, Loader2, Eye, ReceiptText, Fingerprint } from "lucide-react"

export default function ClientDetailPage() {
  const { id } = useParams()
  const db = useFirestore()
  const router = useRouter()

  const clientRef = useMemoFirebase(() => db && id ? doc(db, 'clients', id as string) : null, [db, id])
  const { data: client, loading: loadingClient } = useDoc(clientRef)

  const shipmentsQuery = useMemoFirebase(() => {
    if (!db || !id) return null
    return query(collection(db, 'shipments'), where('clientId', '==', id))
  }, [db, id])
  const { data: shipments, loading: loadingShipments } = useCollection(shipmentsQuery)

  if (loadingClient) return <DashboardLayout><div className="flex justify-center p-20"><Loader2 className="animate-spin h-8 w-8 text-primary" /></div></DashboardLayout>
  if (!client) return <DashboardLayout><div className="text-center py-20 font-bold uppercase text-muted-foreground">Client Record Not Found</div></DashboardLayout>

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <Button variant="ghost" onClick={() => router.back()} className="font-bold uppercase text-[10px] tracking-widest">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Registry
          </Button>
          <div className="flex gap-2">
            <Badge className="bg-primary text-white font-black italic px-4 py-1.5 uppercase tracking-wider h-fit">
              Client ID: SN-{client.id?.substring(0, 4).toUpperCase()}
            </Badge>
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <Card className="border-none shadow-sm h-fit">
            <CardHeader className="bg-primary text-white rounded-t-lg">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-full bg-white/10 flex items-center justify-center font-black italic text-xl">
                  {client.name?.substring(0, 2).toUpperCase()}
                </div>
                <div>
                  <CardTitle className="text-xl font-black italic uppercase tracking-tighter">{client.name}</CardTitle>
                  <CardDescription className="text-white/60 text-[9px] font-bold uppercase tracking-widest">Verified Snoc Business Partner</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="flex items-center gap-3 text-sm">
                <Mail className="h-4 w-4 text-accent" />
                <span className="font-medium">{client.email}</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <Phone className="h-4 w-4 text-accent" />
                <span className="font-medium">{client.phone}</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <MapPin className="h-4 w-4 text-accent" />
                <span className="font-medium">{client.location || 'Not Specified'}</span>
              </div>
              <div className="pt-4 border-t">
                <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest mb-2">Internal Profile Info</p>
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-muted p-2 rounded text-center">
                    <p className="text-lg font-black italic text-primary">{shipments?.length || 0}</p>
                    <p className="text-[8px] uppercase font-bold text-muted-foreground">Total Cargo</p>
                  </div>
                  <div className="bg-muted p-2 rounded text-center">
                    <p className="text-lg font-black italic text-primary">${shipments?.reduce((acc, s) => acc + (s.declaredValue || 0), 0).toLocaleString()}</p>
                    <p className="text-[8px] uppercase font-bold text-muted-foreground">Total Value</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="md:col-span-2 border-none shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg italic text-primary uppercase font-black tracking-tighter">Activity Ledger</CardTitle>
              <CardDescription className="text-[10px] uppercase font-bold tracking-widest">Comprehensive record of consignments handled for this unique ID.</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingShipments ? (
                <div className="flex justify-center p-8"><Loader2 className="animate-spin text-primary" /></div>
              ) : shipments && shipments.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-[10px] uppercase font-bold">Tracking ID</TableHead>
                      <TableHead className="text-[10px] uppercase font-bold">Route</TableHead>
                      <TableHead className="text-[10px] uppercase font-bold">Method</TableHead>
                      <TableHead className="text-[10px] uppercase font-bold">Status</TableHead>
                      <TableHead className="text-right text-[10px] uppercase font-bold">Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {shipments.map((s) => (
                      <TableRow key={s.id} className="hover:bg-primary/5">
                        <TableCell className="font-black italic text-primary uppercase">{s.trackingId}</TableCell>
                        <TableCell className="text-xs">{s.origin?.split(' ')[0]} → GH</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-[10px] font-bold uppercase">{s.method}</Badge>
                        </TableCell>
                        <TableCell>
                           <Badge className={
                            s.status === "Delivered" ? "bg-emerald-100 text-emerald-700 border-emerald-200" :
                            s.status === "In Transit" ? "bg-primary text-white" :
                            "bg-secondary text-secondary-foreground"
                          }>
                            {s.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon" onClick={() => router.push(`/shipments/${s.id}`)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-12">
                  <Package className="h-12 w-12 text-muted-foreground/20 mx-auto mb-4" />
                  <p className="text-muted-foreground text-[10px] font-bold uppercase tracking-widest">No shipment records found for this client ID.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
