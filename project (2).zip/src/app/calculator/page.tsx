
"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Switch } from "@/components/ui/switch"
import { Calculator, Info, Ruler } from "lucide-react"
import { useState, useMemo } from "react"
import { useDoc, useFirestore, useMemoFirebase } from "@/firebase"
import { doc } from "firebase/firestore"

export default function CalculatorPage() {
  const db = useFirestore()
  const [weight, setWeight] = useState<number>(0)
  const [volume, setVolume] = useState<number>(0)
  const [length, setLength] = useState<number>(0)
  const [width, setWidth] = useState<number>(0)
  const [height, setHeight] = useState<number>(0)
  const [method, setMethod] = useState<"air" | "sea">("sea")
  const [useDimensions, setUseDimensions] = useState(false)

  // Fetch rates from Firestore
  const settingsRef = useMemoFirebase(() => db ? doc(db, 'settings', 'global') : null, [db])
  const { data: settings } = useDoc(settingsRef)

  // Default rates if not set in Firestore
  const airRate = settings?.airRatePerKg || 12
  const seaRate = settings?.seaRatePerCbm || 450

  const calculatedVolume = useMemo(() => {
    if (useDimensions) {
      return length * width * height
    }
    return volume
  }, [useDimensions, length, width, height, volume])

  const estimatedCost = useMemo(() => {
    if (method === "air") {
      return weight * airRate
    } else {
      return calculatedVolume * seaRate
    }
  }, [weight, calculatedVolume, method, airRate, seaRate])

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h2 className="text-3xl font-headline font-bold text-primary italic uppercase tracking-tighter">Cost Calculator</h2>
          <p className="text-muted-foreground mt-1 uppercase text-[10px] font-bold tracking-widest">Reliable • Efficient • Trusted Estimate</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="border-none shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg">Cargo Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label>Shipping Method</Label>
                <RadioGroup 
                  defaultValue="sea" 
                  value={method} 
                  onValueChange={(val) => setMethod(val as "air" | "sea")}
                  className="grid grid-cols-2 gap-4"
                >
                  <Label
                    htmlFor="sea"
                    className={`flex items-center justify-between rounded-md border-2 border-muted p-4 hover:bg-accent/5 cursor-pointer transition-all ${method === 'sea' ? 'border-primary bg-primary/5' : ''}`}
                  >
                    <span className="font-bold">Sea Cargo</span>
                    <RadioGroupItem value="sea" id="sea" className="sr-only" />
                  </Label>
                  <Label
                    htmlFor="air"
                    className={`flex items-center justify-between rounded-md border-2 border-muted p-4 hover:bg-accent/5 cursor-pointer transition-all ${method === 'air' ? 'border-primary bg-primary/5' : ''}`}
                  >
                    <span className="font-bold">Air Cargo</span>
                    <RadioGroupItem value="air" id="air" className="sr-only" />
                  </Label>
                </RadioGroup>
              </div>

              {method === "air" ? (
                <div className="space-y-2">
                  <Label htmlFor="weight">Total Weight (kg)</Label>
                  <Input 
                    id="weight" 
                    type="number" 
                    placeholder="e.g. 10.5" 
                    value={weight || ""}
                    onChange={(e) => setWeight(Number(e.target.value))}
                    className="h-12 border-primary/20"
                  />
                  <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">Rate: ${airRate}/kg</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2">
                      <Ruler size={14} className="text-primary" />
                      Calculate by Dimensions
                    </Label>
                    <Switch checked={useDimensions} onCheckedChange={setUseDimensions} />
                  </div>

                  {useDimensions ? (
                    <div className="grid grid-cols-3 gap-2 p-4 rounded-lg bg-muted/30 border">
                      <div className="space-y-1">
                        <Label className="text-[10px] uppercase font-bold">Length (m)</Label>
                        <Input type="number" placeholder="L" value={length || ""} onChange={(e) => setLength(Number(e.target.value))} />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-[10px] uppercase font-bold">Width (m)</Label>
                        <Input type="number" placeholder="W" value={width || ""} onChange={(e) => setWidth(Number(e.target.value))} />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-[10px] uppercase font-bold">Height (m)</Label>
                        <Input type="number" placeholder="H" value={height || ""} onChange={(e) => setHeight(Number(e.target.value))} />
                      </div>
                      <div className="col-span-3 mt-2 pt-2 border-t flex justify-between items-center">
                        <span className="text-xs font-bold text-primary">Calculated CBM:</span>
                        <span className="font-black text-primary italic">{calculatedVolume.toFixed(3)}</span>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Label htmlFor="volume">Total Volume (CBM)</Label>
                      <Input 
                        id="volume" 
                        type="number" 
                        placeholder="e.g. 1.2" 
                        value={volume || ""}
                        onChange={(e) => setVolume(Number(e.target.value))}
                        className="h-12 border-primary/20"
                      />
                    </div>
                  )}
                  <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">Rate: ${seaRate}/CBM</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-none bg-primary text-primary-foreground shadow-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-5">
              <Calculator size={120} />
            </div>
            <CardHeader>
              <CardTitle className="text-white italic tracking-tighter uppercase font-black">Estimation Result</CardTitle>
              <CardDescription className="text-primary-foreground/70 uppercase text-[10px] font-bold tracking-widest">Based on current Snoc market rates.</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center p-8 space-y-6 relative z-10">
              <div className="bg-white/10 rounded-full p-4 border border-white/20 backdrop-blur-sm">
                <Calculator size={48} className="text-accent" />
              </div>
              <div className="text-center">
                <p className="text-[10px] font-black opacity-80 uppercase tracking-[0.3em] mb-2">Estimated Total Cost</p>
                <h3 className="text-6xl font-headline font-black italic tracking-tighter mt-2">${estimatedCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h3>
              </div>
              <p className="text-[10px] text-center opacity-70 italic font-medium uppercase tracking-tight">
                * Rates exclude customs duties, clearing fees, and local handling in Ghana.
              </p>
              <Button className="w-full bg-accent text-white hover:bg-accent/90 border-none font-black italic uppercase tracking-wider h-14 shadow-xl">
                Book Shipment Now
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
