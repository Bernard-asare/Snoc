
"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useUser, useFirestore, useDoc, useMemoFirebase } from "@/firebase"
import { User, Shield, Database, Globe, Save, RefreshCw } from "lucide-react"
import { useState, useEffect } from "react"
import { useToast } from "@/hooks/use-toast"
import { doc, setDoc } from "firebase/firestore"
import { errorEmitter } from "@/firebase/error-emitter"
import { FirestorePermissionError } from "@/firebase/errors"

export default function SettingsPage() {
  const { user } = useUser()
  const db = useFirestore()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)

  // Fetch rates from Firestore
  const settingsRef = useMemoFirebase(() => db ? doc(db, 'settings', 'global') : null, [db])
  const { data: settings, loading: loadingSettings } = useDoc(settingsRef)

  const [airRate, setAirRate] = useState(12)
  const [seaRate, setSeaRate] = useState(450)

  useEffect(() => {
    if (settings) {
      setAirRate(settings.airRatePerKg || 12)
      setSeaRate(settings.seaRatePerCbm || 450)
    }
  }, [settings])

  const handleSaveRates = () => {
    if (!db) return
    setLoading(true)
    
    const payload = {
      airRatePerKg: Number(airRate),
      seaRatePerCbm: Number(seaRate),
      updatedAt: new Date().toISOString()
    }

    setDoc(doc(db, 'settings', 'global'), payload, { merge: true })
      .then(() => {
        toast({
          title: "Rates Updated",
          description: "Shipping constants for Snoc Logistics have been synchronized."
        })
      })
      .catch(async (err) => {
        const permissionError = new FirestorePermissionError({
          path: 'settings/global',
          operation: 'write',
          requestResourceData: payload,
        })
        errorEmitter.emit('permission-error', permissionError)
      })
      .finally(() => setLoading(false))
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-headline font-bold text-primary italic uppercase tracking-tighter">Snoc Administration</h2>
          <p className="text-muted-foreground mt-1 uppercase text-[10px] font-bold tracking-widest">Reliable • Efficient • Trusted Portal Control</p>
        </div>

        <Tabs defaultValue="rates" className="w-full">
          <TabsList className="grid w-full grid-cols-4 lg:w-[600px] bg-muted">
            <TabsTrigger value="rates">Shipping Rates</TabsTrigger>
            <TabsTrigger value="profile">Staff Profile</TabsTrigger>
            <TabsTrigger value="system">System Health</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
          </TabsList>

          <TabsContent value="rates" className="mt-6">
            <Card className="border-none shadow-sm overflow-hidden">
              <CardHeader className="bg-primary text-white border-b-4 border-accent">
                <CardTitle className="flex items-center gap-2 italic uppercase tracking-tighter">
                  <Globe className="h-5 w-5 text-accent" />
                  Global Rate Constants
                </CardTitle>
                <CardDescription className="text-white/70 uppercase text-[10px] font-bold tracking-widest">Adjust the pricing used for automated cost estimations.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2 p-4 rounded-xl border-2 border-primary/10 bg-primary/5">
                    <Label className="text-primary font-black uppercase tracking-widest text-[10px]">Air Cargo Rate ($/kg)</Label>
                    <Input 
                      type="number" 
                      value={airRate} 
                      onChange={(e) => setAirRate(Number(e.target.value))}
                      className="h-12 text-lg font-bold border-primary/20"
                    />
                    <p className="text-[10px] text-muted-foreground italic">Standard Snoc rate for expedited air freight.</p>
                  </div>
                  <div className="space-y-2 p-4 rounded-xl border-2 border-accent/10 bg-accent/5">
                    <Label className="text-accent font-black uppercase tracking-widest text-[10px]">Sea Cargo Rate ($/CBM)</Label>
                    <Input 
                      type="number" 
                      value={seaRate} 
                      onChange={(e) => setSeaRate(Number(e.target.value))}
                      className="h-12 text-lg font-bold border-accent/20"
                    />
                    <p className="text-[10px] text-muted-foreground italic">Standard Snoc rate for container sea freight.</p>
                  </div>
                </div>
                <Button 
                  onClick={handleSaveRates} 
                  disabled={loading}
                  className="bg-primary hover:bg-primary/90 font-black italic uppercase tracking-wider h-12 px-8"
                >
                  {loading ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                  Save Snoc Logistics Rates
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="profile" className="mt-6">
            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-primary italic">
                  <User className="h-5 w-5" />
                  Staff Profile
                </CardTitle>
                <CardDescription>Your personal information within the Snoc ecosystem.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-[10px] uppercase font-bold text-muted-foreground">Full Name</Label>
                    <Input defaultValue={user?.displayName || "Snoc Logistics Admin"} className="bg-muted/50" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-[10px] uppercase font-bold text-muted-foreground">Email Address</Label>
                    <Input defaultValue={user?.email || "admin@snoclogistics.com"} readOnly className="bg-muted" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-[10px] uppercase font-bold text-muted-foreground">Operational Role</Label>
                    <Input defaultValue="Regional Manager" readOnly className="bg-muted" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="system" className="mt-6">
            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-primary italic">
                  <Database className="h-5 w-5" />
                  Cloud Infrastructure
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center p-4 rounded-lg bg-emerald-50 border border-emerald-100">
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-sm font-bold text-emerald-700">Firestore Database Sync</span>
                  </div>
                  <span className="text-xs font-black uppercase text-emerald-600 tracking-widest">Active</span>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="security" className="mt-6">
            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-primary italic">
                  <Shield className="h-5 w-5" />
                  Access Control
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="p-4 rounded-lg bg-accent/5 border border-accent/10">
                  <p className="text-sm font-black text-primary uppercase italic tracking-tight">Super-Admin Privileges</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Your account is authorized to modify global cargo rates and system configurations.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
