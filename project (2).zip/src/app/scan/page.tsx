
"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useEffect, useState, useRef } from "react"
import { Html5QrcodeScanner } from "html5-qrcode"
import { useRouter } from "next/navigation"
import { QrCode, Loader2, Search, ArrowRight, ShieldCheck, AlertCircle } from "lucide-react"
import { useFirestore } from "@/firebase"
import { collection, query, where, getDocs, limit } from "firebase/firestore"
import { useToast } from "@/hooks/use-toast"

export default function ScanPage() {
  const router = useRouter()
  const db = useFirestore()
  const { toast } = useToast()
  const [searching, setSearching] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const scannerRef = useRef<Html5QrcodeScanner | null>(null)

  useEffect(() => {
    // Delay initialization to ensure the DOM element "qr-reader" exists
    const timer = setTimeout(() => {
      const element = document.getElementById("qr-reader");
      if (!element) return;

      try {
        const scanner = new Html5QrcodeScanner(
          "qr-reader",
          { fps: 10, qrbox: { width: 250, height: 250 } },
          /* verbose= */ false
        )

        scanner.render(onScanSuccess, onScanFailure)
        scannerRef.current = scanner
      } catch (err) {
        console.error("Scanner initialization failed", err)
      }
    }, 300);

    return () => {
      clearTimeout(timer);
      if (scannerRef.current) {
        scannerRef.current.clear().catch(err => {
          // Ignore clear errors if component is already unmounted
        })
      }
    }
  }, [])

  async function onScanSuccess(decodedText: string) {
    if (searching) return
    
    setSearching(true)
    setError(null)

    if (scannerRef.current) {
      scannerRef.current.pause()
    }

    try {
      // Logic: Scanned text should be a Tracking ID like "GL-1001"
      const q = query(
        collection(db, "shipments"),
        where("trackingId", "==", decodedText.trim().toUpperCase()),
        limit(1)
      )

      const querySnapshot = await getDocs(q)
      
      if (querySnapshot.empty) {
        setError(`No shipment found for ID: ${decodedText}`)
        setSearching(false)
        if (scannerRef.current) scannerRef.current.resume()
      } else {
        const shipmentDoc = querySnapshot.docs[0]
        toast({ title: "Shipment Located", description: `Record for ${decodedText} identified.` })
        router.push(`/shipments/${shipmentDoc.id}`)
      }
    } catch (err) {
      console.error(err)
      setError("Database lookup failed. Please try again.")
      setSearching(false)
      if (scannerRef.current) scannerRef.current.resume()
    }
  }

  function onScanFailure(error: any) {
    // Non-critical scanning failures are normal (e.g. no QR in frame)
  }

  return (
    <DashboardLayout>
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="flex items-center justify-between border-b pb-6">
          <div>
            <h2 className="text-3xl font-headline font-black italic text-primary uppercase tracking-tighter">Terminal Scanner</h2>
            <p className="text-muted-foreground font-bold uppercase text-[10px] tracking-widest">Reliable • Efficient • Instant Tracking</p>
          </div>
          <div className="bg-primary/5 p-3 rounded-full text-primary">
            <QrCode size={24} />
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="border-none shadow-xl overflow-hidden bg-white relative">
            <CardHeader className="bg-primary text-white border-b-4 border-accent">
              <CardTitle className="text-lg italic uppercase tracking-tighter">Live Camera Hub</CardTitle>
              <CardDescription className="text-white/70 text-[10px] uppercase font-bold">Align package QR code within the frame.</CardDescription>
            </CardHeader>
            <CardContent className="p-0 min-h-[300px]">
               <div id="qr-reader" className="border-none [&>div]:border-none [&_video]:rounded-b-lg"></div>
               {searching && (
                 <div className="absolute inset-0 bg-primary/20 backdrop-blur-sm flex flex-col items-center justify-center space-y-4 z-20">
                    <Loader2 className="h-12 w-12 text-primary animate-spin" />
                    <p className="font-black italic text-primary uppercase tracking-tighter">Querying Snoc Hub...</p>
                 </div>
               )}
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card className="border-none shadow-sm bg-accent/5">
              <CardHeader>
                <CardTitle className="text-sm font-black italic text-primary uppercase">Operational Instructions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-xs font-medium text-primary/80">
                <div className="flex gap-3 items-start">
                   <div className="h-5 w-5 rounded-full bg-primary text-white flex items-center justify-center shrink-0 font-bold">1</div>
                   <p>Ensure the QR code is well-lit and not obscured by tape.</p>
                </div>
                <div className="flex gap-3 items-start">
                   <div className="h-5 w-5 rounded-full bg-primary text-white flex items-center justify-center shrink-0 font-bold">2</div>
                   <p>Hold the device steady until the "Shipment Located" notification appears.</p>
                </div>
                <div className="flex gap-3 items-start">
                   <div className="h-5 w-5 rounded-full bg-primary text-white flex items-center justify-center shrink-0 font-bold">3</div>
                   <p>The system will automatically redirect you to the shipment detail page.</p>
                </div>
              </CardContent>
            </Card>

            {error && (
              <div className="p-4 rounded-xl bg-destructive/10 border-2 border-destructive/20 text-destructive flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
                <AlertCircle size={20} />
                <p className="text-xs font-bold uppercase">{error}</p>
                <Button variant="ghost" size="sm" onClick={() => { setError(null); if (scannerRef.current) scannerRef.current.resume(); }} className="ml-auto h-8 text-[10px] font-black uppercase">Retry</Button>
              </div>
            )}

            <div className="bg-primary rounded-xl p-6 text-white space-y-4 shadow-lg border-b-4 border-accent">
               <div className="flex items-center gap-3">
                 <ShieldCheck className="text-accent" />
                 <h4 className="font-black italic uppercase tracking-tighter">Verified Access</h4>
               </div>
               <p className="text-[10px] font-medium uppercase tracking-widest opacity-80 leading-relaxed">
                 Scanner interface is encrypted and restricted to authorized Snoc Logistics personnel.
               </p>
               <Button variant="outline" className="w-full border-white/20 text-white hover:bg-white/10 font-bold uppercase italic text-xs tracking-wider" onClick={() => router.push('/shipments')}>
                 Manual Search Registry <ArrowRight className="ml-2 h-3 w-3" />
               </Button>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
