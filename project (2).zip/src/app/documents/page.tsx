
"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useState, useEffect } from "react"
import { generateShippingDocuments, GenerateShippingDocumentsOutput } from "@/ai/flows/generate-shipping-documents"
import { Loader2, FileText, Download, Wand2, Plus, Trash2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function DocumentsPage() {
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [result, setResult] = useState<GenerateShippingDocumentsOutput | null>(null)

  const [formData, setFormData] = useState({
    shipmentId: "",
    senderName: "Shenzhen Electronics Co.",
    senderAddress: "Building B, Huqiangbei Road, Shenzhen, China",
    recipientName: "TechHub Solutions Ghana",
    recipientAddress: "15 Oxford St, Osu, Accra, Ghana",
    totalWeightKg: 12.5,
    totalVolumeCbm: 0.05,
    declaredValue: 1200,
    currency: "USD",
    countryOfOrigin: "China",
    purposeOfShipment: "Sale",
    shippingDate: "",
    items: [{ description: "Wireless Earbuds", quantity: 50, valuePerItem: 20, hsCode: "8518.30" }]
  })

  useEffect(() => {
    setMounted(true)
    // Avoid hydration mismatch by generating IDs only on client mount
    setFormData(prev => ({
      ...prev,
      shipmentId: "GL-" + Math.floor(1000 + Math.random() * 9000),
      shippingDate: new Date().toISOString().split('T')[0]
    }))
  }, [])

  const addItem = () => {
    setFormData(prev => ({
      ...prev,
      items: [...prev.items, { description: "", quantity: 1, valuePerItem: 0, hsCode: "" }]
    }))
  }

  const removeItem = (index: number) => {
    setFormData(prev => ({
      ...prev,
      items: prev.items.filter((_, i) => i !== index)
    }))
  }

  const updateItem = (index: number, field: string, value: any) => {
    const newItems = [...formData.items]
    newItems[index] = { ...newItems[index], [field]: value }
    setFormData(prev => ({ ...prev, items: newItems }))
  }

  const handleGenerate = async () => {
    setLoading(true)
    try {
      const output = await generateShippingDocuments(formData)
      setResult(output)
      toast({
        title: "Documents Generated",
        description: "AI successfully created your shipping documents."
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Generation Failed",
        description: "There was an error generating your documents."
      })
    } finally {
      setLoading(false)
    }
  }

  if (!mounted) return null

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div>
          <h2 className="text-3xl font-headline font-bold text-primary italic uppercase tracking-tighter">AI Documentation Assistant</h2>
          <p className="text-muted-foreground mt-1 uppercase text-[10px] font-bold tracking-widest">Reliable • Efficient • Trusted AI Tools</p>
        </div>

        <div className="grid gap-8 lg:grid-cols-2">
          <Card className="border-none shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg">Shipment Data</CardTitle>
              <CardDescription className="text-xs">Fill in the details for AI processing.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-[10px] font-bold uppercase">Tracking #</Label>
                  <Input value={formData.shipmentId} readOnly className="bg-muted" />
                </div>
                <div className="space-y-2">
                  <Label className="text-[10px] font-bold uppercase">Shipping Date</Label>
                  <Input type="date" value={formData.shippingDate} onChange={e => setFormData({...formData, shippingDate: e.target.value})} />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-[10px] font-bold uppercase">Sender (China)</Label>
                <Input value={formData.senderName} onChange={e => setFormData({...formData, senderName: e.target.value})} />
              </div>

              <div className="space-y-2">
                <Label className="text-[10px] font-bold uppercase">Recipient (Ghana)</Label>
                <Input value={formData.recipientName} onChange={e => setFormData({...formData, recipientName: e.target.value})} />
              </div>

              <div className="space-y-4 pt-4 border-t">
                <div className="flex items-center justify-between">
                  <Label className="text-[10px] font-bold uppercase">Items List</Label>
                  <Button variant="ghost" size="sm" onClick={addItem} className="h-8">
                    <Plus className="h-4 w-4 mr-1" /> Add Item
                  </Button>
                </div>
                
                {formData.items.map((item, index) => (
                  <div key={index} className="space-y-3 p-3 rounded-lg border bg-muted/20 relative group">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="absolute top-1 right-1 h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity text-destructive"
                      onClick={() => removeItem(index)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                    <Input 
                      placeholder="Item description" 
                      value={item.description} 
                      onChange={e => updateItem(index, 'description', e.target.value)}
                    />
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <Label className="text-[10px] uppercase">Qty</Label>
                        <Input type="number" value={item.quantity} onChange={e => updateItem(index, 'quantity', Number(e.target.value))} />
                      </div>
                      <div>
                        <Label className="text-[10px] uppercase">Val/Item ($)</Label>
                        <Input type="number" value={item.valuePerItem} onChange={e => updateItem(index, 'valuePerItem', Number(e.target.value))} />
                      </div>
                      <div>
                        <Label className="text-[10px] uppercase">HS Code</Label>
                        <Input placeholder="Code" value={item.hsCode} onChange={e => updateItem(index, 'hsCode', e.target.value)} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <Button 
                onClick={handleGenerate} 
                disabled={loading}
                className="w-full bg-primary hover:bg-primary/90 mt-4 h-12 font-black italic uppercase tracking-wider"
              >
                {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Wand2 className="mr-2 h-4 w-4" />}
                Generate Documents
              </Button>
            </CardContent>
          </Card>

          <div className="space-y-6">
            {!result ? (
              <div className="h-full min-h-[400px] rounded-xl border-2 border-dashed flex flex-col items-center justify-center text-muted-foreground p-8 text-center bg-muted/5">
                <FileText className="h-12 w-12 mb-4 opacity-20" />
                <h3 className="text-lg font-bold italic text-primary uppercase">No Documents Generated</h3>
                <p className="max-w-[300px] mt-2 text-xs uppercase tracking-widest font-medium">Fill in the shipment data and click generate to see AI-powered documents here.</p>
              </div>
            ) : (
              <>
                <Card className="border-none shadow-md overflow-hidden bg-accent/5">
                  <CardHeader className="bg-accent/10">
                    <CardTitle className="flex items-center gap-2 text-primary font-black italic uppercase tracking-tight">
                      <FileText className="h-5 w-5" />
                      Shipment Summary
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <p className="text-sm leading-relaxed italic">{result.summary}</p>
                  </CardContent>
                </Card>

                <div className="space-y-4">
                  <Card className="border-none shadow-sm">
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-xs uppercase tracking-[0.2em] text-muted-foreground font-black">Customs Declaration</CardTitle>
                        <Button variant="ghost" size="icon" className="h-8 w-8"><Download className="h-4 w-4" /></Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <pre className="text-[10px] p-4 bg-muted rounded-md overflow-auto whitespace-pre-wrap font-mono leading-tight max-h-48 border border-primary/10">
                        {result.customsDeclaration}
                      </pre>
                    </CardContent>
                  </Card>

                  <Card className="border-none shadow-sm">
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-xs uppercase tracking-[0.2em] text-muted-foreground font-black">Packing List</CardTitle>
                        <Button variant="ghost" size="icon" className="h-8 w-8"><Download className="h-4 w-4" /></Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <pre className="text-[10px] p-4 bg-muted rounded-md overflow-auto whitespace-pre-wrap font-mono leading-tight max-h-48 border border-primary/10">
                        {result.packingList}
                      </pre>
                    </CardContent>
                  </Card>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
