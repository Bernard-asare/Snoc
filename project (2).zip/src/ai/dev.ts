
import { config } from 'dotenv';
config();

import '@/ai/flows/generate-shipping-documents.ts';
import '@/ai/flows/shipment-voice-flow.ts';
