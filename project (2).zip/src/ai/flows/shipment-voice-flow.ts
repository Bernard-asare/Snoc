
'use server';
/**
 * @fileOverview A shipment status voice update AI flow.
 *
 * - generateShipmentVoiceUpdate - A function that converts shipment data into spoken audio.
 * - VoiceUpdateInput - Input schema for the voice update.
 * - VoiceUpdateOutput - Output schema containing the audio data URI.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { googleAI } from '@genkit-ai/google-genai';
import wav from 'wav';

const VoiceUpdateInputSchema = z.object({
  trackingId: z.string().describe('The shipment tracking ID.'),
  status: z.string().describe('Current status of the shipment.'),
  latestNote: z.string().optional().describe('The most recent update note.'),
  location: z.string().optional().describe('Current location of the cargo.'),
  method: z.string().optional().describe('Shipping method (Air or Sea).'),
});
export type VoiceUpdateInput = z.infer<typeof VoiceUpdateInputSchema>;

const VoiceUpdateOutputSchema = z.object({
  audioDataUri: z.string().describe('Base64 encoded WAV audio data URI.'),
});
export type VoiceUpdateOutput = z.infer<typeof VoiceUpdateOutputSchema>;

async function toWav(
  pcmData: Buffer,
  channels = 1,
  rate = 24000,
  sampleWidth = 2
): Promise<string> {
  return new Promise((resolve, reject) => {
    const writer = new wav.Writer({
      channels,
      sampleRate: rate,
      bitDepth: sampleWidth * 8,
    });

    let bufs: Buffer[] = [];
    writer.on('error', reject);
    writer.on('data', function (d) {
      bufs.push(d);
    });
    writer.on('end', function () {
      resolve(Buffer.concat(bufs).toString('base64'));
    });

    writer.write(pcmData);
    writer.end();
  });
}

export async function generateShipmentVoiceUpdate(input: VoiceUpdateInput): Promise<VoiceUpdateOutput> {
  return shipmentVoiceUpdateFlow(input);
}

const shipmentVoiceUpdateFlow = ai.defineFlow(
  {
    name: 'shipmentVoiceUpdateFlow',
    inputSchema: VoiceUpdateInputSchema,
    outputSchema: VoiceUpdateOutputSchema,
  },
  async (input) => {
    const query = `
      Hello! This is an automated update from Snoc Logistics. 
      Your shipment with tracking ID ${input.trackingId} is currently ${input.status}. 
      ${input.location ? `The cargo is at ${input.location}.` : ''}
      The latest update states: ${input.latestNote || 'Everything is progressing as planned.'}
      Thank you for choosing Snoc Logistics. Reliable, efficient, and trusted.
    `;

    const { media } = await ai.generate({
      model: googleAI.model('gemini-2.5-flash-preview-tts'),
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Algenib' },
          },
        },
      },
      prompt: query,
    });

    if (!media || !media.url) {
      throw new Error('No audio media returned from model');
    }

    const audioBuffer = Buffer.from(
      media.url.substring(media.url.indexOf(',') + 1),
      'base64'
    );

    const wavBase64 = await toWav(audioBuffer);
    
    return {
      audioDataUri: `data:audio/wav;base64,${wavBase64}`,
    };
  }
);
