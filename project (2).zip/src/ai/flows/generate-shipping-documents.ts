'use server';
/**
 * @fileOverview An AI documentation assistant for generating shipping documents.
 *
 * - generateShippingDocuments - A function that handles the generation of shipping documents.
 * - GenerateShippingDocumentsInput - The input type for the generateShippingDocuments function.
 * - GenerateShippingDocumentsOutput - The return type for the generateShippingDocuments function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const GenerateShippingDocumentsInputSchema = z.object({
  shipmentId: z.string().describe('Unique identifier for the shipment.'),
  senderName: z.string().describe('Full name of the sender.'),
  senderAddress: z.string().describe('Full address of the sender.'),
  recipientName: z.string().describe('Full name of the recipient.'),
  recipientAddress: z.string().describe('Full address of the recipient.'),
  items: z.array(z.object({
    description: z.string().describe('Description of the item.'),
    quantity: z.number().int().positive().describe('Quantity of the item.'),
    valuePerItem: z.number().positive().describe('Value per single item.'),
    hsCode: z.string().describe('Harmonized System (HS) code for customs declaration.'),
  })).min(1).describe('List of items included in the shipment.'),
  totalWeightKg: z.number().positive().describe('Total weight of the shipment in kilograms.'),
  totalVolumeCbm: z.number().positive().describe('Total volume of the shipment in cubic meters.'),
  declaredValue: z.number().positive().describe('Total declared value of the shipment for customs.'),
  currency: z.string().describe('Currency of the declared value (e.g., "USD", "GHS").'),
  countryOfOrigin: z.string().describe('Country where the goods were manufactured or produced.'),
  purposeOfShipment: z.string().describe('Purpose of the shipment (e.g., "Commercial Sample", "Gift", "Sale").'),
  shippingDate: z.string().describe('Date of shipment in YYYY-MM-DD format.'),
});
export type GenerateShippingDocumentsInput = z.infer<typeof GenerateShippingDocumentsInputSchema>;

const GenerateShippingDocumentsOutputSchema = z.object({
  customsDeclaration: z.string().describe('The generated customs declaration document content in a structured text format.'),
  packingList: z.string().describe('The generated packing list document content in a structured text format.'),
  summary: z.string().describe('A brief summary of the generated documents and key shipment details.'),
});
export type GenerateShippingDocumentsOutput = z.infer<typeof GenerateShippingDocumentsOutputSchema>;

export async function generateShippingDocuments(input: GenerateShippingDocumentsInput): Promise<GenerateShippingDocumentsOutput> {
  return generateShippingDocumentsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateShippingDocumentsPrompt',
  input: { schema: GenerateShippingDocumentsInputSchema },
  output: { schema: GenerateShippingDocumentsOutputSchema },
  prompt: `You are an AI documentation assistant specialized in international shipping between China and Ghana. Your task is to generate accurate and complete shipping documents based on the provided shipment data.

Generate two primary documents: a Customs Declaration and a Packing List. Ensure all required information is included in a clear, structured, and professional format. Then provide a brief summary of the documents.

--- Shipment Data ---
Shipment ID: {{{shipmentId}}}
Sender Name: {{{senderName}}}
Sender Address: {{{senderAddress}}}
Recipient Name: {{{recipientName}}}
Recipient Address: {{{recipientAddress}}}
Total Weight: {{{totalWeightKg}}} kg
Total Volume: {{{totalVolumeCbm}}} cbm
Declared Value: {{{currency}}} {{{declaredValue}}}
Country of Origin: {{{countryOfOrigin}}}
Purpose of Shipment: {{{purposeOfShipment}}}
Shipping Date: {{{shippingDate}}}

Items in Shipment:
{{#each items}}
- Description: {{{this.description}}}
  Quantity: {{{this.quantity}}}
  Value Per Item: {{{../currency}}} {{{this.valuePerItem}}}
  HS Code: {{{this.hsCode}}}
{{/each}}

---

Instructions for Customs Declaration:
- Include sender and recipient details.
- List each item with its description, quantity, value per item, total value for that item, HS Code, and country of origin.
- State the total declared value, total weight, and purpose of shipment.
- Add a standard declaration statement for customs purposes, indicating accuracy of information.

Instructions for Packing List:
- Include shipment ID, sender, and recipient details.
- List each item with its description and quantity.
- Focus on what is packed.

Generate the output in JSON format as per the specified schema for 'customsDeclaration', 'packingList', and 'summary'.`,
});

const generateShippingDocumentsFlow = ai.defineFlow(
  {
    name: 'generateShippingDocumentsFlow',
    inputSchema: GenerateShippingDocumentsInputSchema,
    outputSchema: GenerateShippingDocumentsOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
