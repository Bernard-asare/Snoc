'use client';

import { useMemo, useRef } from 'react';

/**
 * Custom hook to memoize Firebase queries or references.
 * Prevents infinite loops caused by inline query definitions.
 */
export function useMemoFirebase<T>(factory: () => T, dependencies: any[]): T {
  const ref = useRef<T>(null as any);
  const depsRef = useRef<any[]>([]);

  const changed = dependencies.length !== depsRef.current.length || 
    dependencies.some((dep, i) => dep !== depsRef.current[i]);

  if (changed) {
    ref.current = factory();
    depsRef.current = dependencies;
  }

  return ref.current;
}
